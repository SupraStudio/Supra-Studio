"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { getDict, LOCALES, CALENDLY_URL, type Lang, localizedHref, stripLocaleFromPath } from "@/lib/i18n";
import SocialLinks from "@/components/SocialLinks";

export default function Header({
  hasHero = true,
  lang = "fr",
}: {
  hasHero?: boolean;
  lang?: Lang;
}) {
  const t = getDict(lang);
  const pathname = usePathname() || "/";
  const basePath = stripLocaleFromPath(pathname);

  const NAV_LINKS = [
    { label: t.nav.studio, href: localizedHref("/studio", lang) },
    { label: t.nav.projects, href: localizedHref("/projets", lang) },
    { label: t.nav.journal, href: localizedHref("/journal", lang) },
    { label: t.nav.services, href: localizedHref("/services", lang) },
    { label: t.nav.contact, href: localizedHref("/contact", lang) },
  ];

  const [scrolled, setScrolled] = useState(!hasHero);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    if (!hasHero) return;
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [hasHero]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  const LangLinks = () => (
    <>
      {LOCALES.map((l, i) => (
        <span key={l} style={{ display: "flex", gap: 6 }}>
          <a
            href={localizedHref(basePath, l)}
            className={lang === l ? "active" : ""}
            onClick={() => {
              document.cookie = `supra_lang=${l};max-age=${60 * 60 * 24 * 365};path=/`;
            }}
          >
            {l.toUpperCase()}
          </a>
          {i < LOCALES.length - 1 && <span aria-hidden="true">/</span>}
        </span>
      ))}
    </>
  );

  return (
    <header className={`site-header${scrolled ? " is-scrolled" : ""}`}>
      <a href={localizedHref("/", lang)} className="logo" aria-label="Supra Studio — Accueil">
        <img src="/assets/icons/logo-supra-studio-architecte-interieur-paysagiste.svg" alt="Supra Studio" />
      </a>

      <nav className={`main-nav${open ? " is-open" : ""}`} aria-label="Navigation principale">
        {NAV_LINKS.map((l) => (
          <a key={l.href} href={l.href} onClick={() => setOpen(false)}>
            {l.label}
          </a>
        ))}
        <div className="mobile-lang">
          <LangLinks />
        </div>
        <SocialLinks className="mobile-socials" />
      </nav>

      <div className="header-right">
        <div className="lang-switch">
          <LangLinks />
        </div>
        <a
          href={CALENDLY_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-header-cta"
        >
          <span className="cta-full">{t.bookAppointment}</span>
          <span className="cta-short">{t.bookShort}</span>
        </a>
        <button
          className={`nav-toggle${open ? " is-open" : ""}`}
          aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
}
