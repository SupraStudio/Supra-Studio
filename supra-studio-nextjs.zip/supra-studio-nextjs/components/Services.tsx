import { getDict, CALENDLY_URL, type Lang } from "@/lib/i18n";

export default function Services({
  hideCta = false,
  asH1 = false,
  lang = "fr",
}: {
  hideCta?: boolean;
  asH1?: boolean;
  lang?: Lang;
}) {
  const t = getDict(lang);
  const Title = asH1 ? "h1" : "h2";
  return (
    <section className="services" id="services">
      <div className="wrap">
        <div className="section-label reveal">
          <span>{t.servicesPage.label}</span>
        </div>
        <Title className="section-title reveal" style={{ marginBottom: 24 }}>
          {asH1 ? t.servicesPage.h1Title : t.servicesPage.title}
        </Title>
        <p className="services-intro reveal">{t.servicesPage.intro}</p>

        <div className="services-grid reveal">
          {t.servicesPage.steps.map((s) => (
            <div className="service-card" key={s.num}>
              <span className="service-num">{s.num}</span>
              <h3>{s.title}</h3>
              <p className="tag">{s.tag}</p>
              <p className="service-card-body">{s.body}</p>
            </div>
          ))}
        </div>
      </div>

      {!hideCta && (
        <div className="services-cta-bleed reveal">
          <div className="services-cta">
            <p>{t.ctaLine}</p>
            <a
              href={CALENDLY_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-light"
            >
              {t.bookAppointment}
            </a>
          </div>
        </div>
      )}
    </section>
  );
}
