export type JournalArticle = {
  slug: string;
  title: string;
  // Titre optimisé pour la balise <title> (SEO), s'il diffère du H1 affiché. Sinon `title` est réutilisé.
  metaTitle?: string;
  excerpt: string;
  // Format ISO (YYYY-MM-DD) — utilisé pour le tri, l'affichage et les données structurées.
  date: string;
  category: string;
  cover: string;
  // Image utilisée pour le bandeau (hero) de la page détail. Si absente, on retombe sur `cover`.
  heroImage?: string;
  readingTime?: string;
  // Chapô affiché juste sous le H1, avant les sections.
  intro?: string;
  // Articles courts : paragraphes simples, sans sous-titres.
  content?: string[];
  // Articles longs : sections avec sous-titre H2 + paragraphes (comme les pages projet).
  // `image` optionnelle : illustration insérée dans la section.
  // `afterParagraph` (index 0-based) place l'image juste après ce paragraphe précis ;
  // sans cet index, l'image est insérée à la fin de la section (comportement par défaut).
  sections?: {
    heading: string;
    paragraphs: string[];
    image?: { src: string; caption?: string; afterParagraph?: number };
  }[];
  keywords?: string[];
  // Slugs des projets (lib/projects.ts) en lien thématique avec l'article, affichés en
  // bas de la page détail.
  relatedProjects?: string[];
  // Si true, l'article reste toujours en tête de la liste du Journal, quelle que soit sa date.
  pinned?: boolean;
};

// Source de vérité en français. Les traductions EN/IT vivent dans journal.i18n.ts
// (même logique que lib/projects.ts / lib/projects.i18n.ts).
export const JOURNAL_ARTICLES: JournalArticle[] = [
  {
    slug: "pourquoi-faire-appel-architecte-interieur-paris",
    title: "Pourquoi faire appel à un architecte d'intérieur à Paris ?",
    excerpt:
      "Rénovation, gain de temps, réseau d'artisans, valorisation du bien : découvrez pourquoi faire appel à un architecte d'intérieur à Paris change tout dans votre projet.",
    date: "2026-07-28",
    category: "Conseils & expertise",
    cover: "/assets/images/architectes-echange-materiaux-projet-paris.png",
    readingTime: "6 min",
    sections: [
      {
        heading:
          "Un métier qui va bien au-delà du choix des couleurs et du mobilier",
        paragraphs: [
          "C'est sans doute l'idée reçue la plus tenace : on imagine l'architecte d'intérieur comme quelqu'un qui vient choisir une peinture ou assortir des coussins. En réalité, son travail commence bien avant — dans la compréhension de l'existant. Contraintes structurelles du bâti, circulation de la lumière naturelle, emplacement des réseaux (eau, électricité, ventilation), règles de copropriété : autant d'éléments techniques qu'un œil non averti ne sait pas toujours lire, et qui déterminent pourtant ce qu'il est réellement possible de faire dans un lieu.",
          "Un architecte d'intérieur conçoit un projet global — plans, volumes, matières, lumière, usages — avant de s'intéresser à la décoration. C'est cette vision d'ensemble qui distingue un intérieur pensé d'un intérieur simplement décoré.",
        ],
        image: {
          src: "/assets/images/architectes-echange-materiaux-projet-paris.png",
          caption: "Échange autour des matériaux et des plans d'un projet, Supra Studio",
        },
      },
      {
        heading: "Gagner du temps et éviter les erreurs coûteuses",
        paragraphs: [
          "À Paris, un projet de rénovation mal anticipé se traduit vite par des surprises : un mur porteur qu'on ne peut pas abattre, une cuisine qu'il faut déplacer à cause d'une évacuation existante, des travaux qui prennent deux fois plus de temps que prévu faute d'avoir été correctement séquencés.",
          "Un architecte d'intérieur identifie ces contraintes en amont, dès la phase d'étude de faisabilité, avant que le chantier ne commence. Ce travail préparatoire, souvent perçu comme une dépense supplémentaire, est en réalité ce qui évite les dépenses imprévues les plus importantes : reprises de travaux, changements de plan en cours de chantier, matériaux commandés puis finalement inadaptés.",
        ],
      },
      {
        heading: "Un accès à un réseau d'artisans et d'entreprises qualifiées",
        paragraphs: [
          "Trouver un artisan de confiance à Paris — disponible, compétent, capable de respecter un délai — reste l'un des points les plus chronophages d'un projet de rénovation mené seul. Un architecte d'intérieur travaille avec un réseau d'entreprises et d'artisans déjà éprouvés, choisis pour la qualité de leur travail autant que pour leur fiabilité.",
          "Cet accompagnement ne s'arrête d'ailleurs pas à la mise en relation : le suivi de chantier permet de vérifier que ce qui est réalisé correspond fidèlement à ce qui a été conçu, sans que le client ait à être présent sur site en permanence pour arbitrer chaque détail.",
        ],
      },
      {
        heading: "Valoriser durablement votre bien immobilier",
        paragraphs: [
          "Un intérieur bien pensé — qui optimise la lumière, fluidifie les circulations et exploite intelligemment chaque mètre carré — a un impact direct sur la valeur d'un bien, particulièrement dans un marché parisien où chaque mètre carré compte. À l'inverse, une rénovation mal conçue, même avec des matériaux de qualité, peut au mieux ne rien apporter, au pire desservir la revente future.",
          "Faire appel à un architecte d'intérieur, c'est donc aussi un choix patrimonial : celui d'un lieu conçu pour traverser le temps, plutôt que de suivre une tendance qui se démodera.",
        ],
      },
      {
        heading: "Un intérieur pensé pour votre mode de vie, pas pour un catalogue",
        paragraphs: [
          "Chaque foyer, chaque famille, chaque manière de recevoir ou de travailler chez soi est différente. Un bon architecte d'intérieur ne propose pas un style figé à appliquer partout : il construit une réponse sur-mesure, à partir de vos usages réels — la façon dont vous circulez dans votre logement, dont vous recevez, dont vous travaillez, dont vous vivez au quotidien.",
          "C'est cette dimension sur-mesure qui distingue un projet d'architecture intérieure d'un simple relooking : le lieu s'adapte à vous, pas l'inverse.",
        ],
      },
      {
        heading: "Pourquoi faire appel à Supra Studio ?",
        paragraphs: [
          "Chez Supra Studio, nous abordons chaque projet avec une conviction simple : la lumière et la justesse des matériaux suffisent, la plupart du temps, à transformer un lieu — sans artifice ni superflu. Notre studio, fondé par un duo franco-italien, réunit une double compétence en architecture d'intérieur et en architecture paysagère, une combinaison rare qui nous permet de penser vos espaces intérieurs et extérieurs comme un tout cohérent, plutôt que comme deux projets séparés.",
          "Concrètement, notre accompagnement se déroule en quatre étapes claires : une **visite conseil** pour comprendre votre espace et vos besoins avant tout engagement, une étude de **faisabilité** technique et budgétaire, une phase de **conception** où plans, volumes et matières prennent forme, puis un **suivi de travaux** rigoureux jusqu'à la livraison — avec notre réseau d'artisans et d'entreprises locales, choisis avec la même exigence à chaque projet.",
          "Basés entre Paris, Bordeaux et Rome, nous privilégions les matériaux naturels, les lignes épurées et une approche écoresponsable, pour des intérieurs sensibles et durables plutôt que suivant une mode passagère. Que votre projet soit une rénovation d'appartement, la conception d'une maison neuve ou l'aménagement d'un jardin, notre studio vous accompagne de la première esquisse à la réception du chantier.",
          "**Vous avez un projet de rénovation ou d'aménagement intérieur à Paris ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une première visite conseil, ou [contactez-nous](/contact) pour en discuter.",
        ],
        image: {
          src: "/assets/images/paul-beatrice-fondateurs-supra-studio.jpg",
          caption: "Paul et Beatrice, fondateurs de Supra Studio",
          afterParagraph: 0,
        },
      },
    ],
    keywords: [
      "Architecte d'intérieur Paris",
      "Rénovation appartement Paris",
      "Conseils rénovation",
    ],
    relatedProjects: ["casa-duy", "maison-kleber"],
    pinned: true,
  },
  {
    slug: "continuite-visuelle-interieur-jardin-architecture-in-out",
    title: "Comment créer une continuité visuelle entre l'intérieur et le jardin ?",
    metaTitle: "Architecture In & Out : Créer une Continuité entre Intérieur et Jardin",
    excerpt:
      "Découvrez comment l'architecture d'intérieur et le design paysager s'unissent pour effacer les frontières entre maison et jardin. Conseils d'expert In & Out.",
    date: "2026-06-30",
    category: "Architecture d'Intérieur & Paysage",
    cover: "/assets/images/continuite-interieur-jardin-terrasse-jour.png",
    readingTime: "5 min",
    intro:
      "Effacer la frontière entre le cocon intérieur et le paysage extérieur est l'un des piliers de l'architecture contemporaine. Quand le séjour semble se prolonger sur la terrasse et que le jardin s'invite dans le salon, l'espace gagne en volume, en sérénité et en clarté. Décryptage d'une démarche de conception In & Out.",
    sections: [
      {
        heading: "L'Architecture In & Out : Redéfinir les limites de l'habiter",
        paragraphs: [
          "Pendant longtemps, l'architecture a pensé la maison et le jardin comme deux entités distinctes : l'intérieur pour le confort et l'abri, l'extérieur pour la nature et la détente. Aujourd'hui, l'approche globale In & Out renverse cette frontière rigide pour créer un espace de vie fluide et unifié.",
          "Créer une véritable continuité visuelle ne se résume pas à poser une baie vitrée. Il s'agit d'une orchestration minutieuse où les matériaux, la lumière, la palette végétale et la géométrie des pièces dialoguent pour offrir une sensation de respiration permanente.",
        ],
      },
      {
        heading: "1. L'alignement des sols : L'illusion d'un espace infini",
        paragraphs: [
          "Le premier vecteur de continuité est le sol. Lorsque le regard glisse sans interruption de la pièce de vie vers la terrasse, le cerveau perçoit immédiatement l'extérieur comme une extension naturelle du salon.",
          "**La continuité matérielle :** utiliser le même matériau — ou sa déclinaison adaptée aux intempéries — à l'intérieur et à l'extérieur. Un béton ciré d'intérieur associé à un béton désactivé coordonné, ou une pierre naturelle posée en opus à l'intérieur et déclinée en dalles antidérapantes sur la terrasse.",
          "**Le seuil encastré :** éliminer les ressauts visuels et physiques grâce à des baies coulissantes à galandage avec rails encastrés dans le sol. La transition devient parfaitement invisible.",
          "**La trame de pose :** conserver le même sens de pose pour les lames de parquet d'intérieur et les lames de terrasse en bois ou grès cérame extérieur.",
        ],
        image: {
          src: "/assets/images/continuite-interieur-jardin-terrasse-jour.png",
          caption: "Continuité du sol entre le séjour et la terrasse",
        },
      },
      {
        heading: "2. La palette chromatique et minérale comme fil conducteur",
        paragraphs: [
          "Pour que le jardin résonne avec votre décoration d'intérieur, la sélection des teintes et des textures doit faire l'objet d'un travail d'ensemble dès la phase de conception.",
          "En choisissant des matériaux nobles et sobres — comme le bois de chêne, la chaux brossée, le granit égrisé ou l'acier thermolaqué noir —, vous créez une toile de fond intemporelle. Reprendre les teintes des murs intérieurs sur les murets du jardin ou sur les façades ombragées du patio permet de lier subtilement le bâti à la nature environnante.",
        ],
      },
      {
        heading: "3. Scénographier le paysage depuis l'intérieur",
        paragraphs: [
          "Penser le jardin depuis le salon consiste à créer des « tableaux vivants ». Chaque ouverture devient un cadre qui met en valeur la composition paysagère.",
          "En plaçant un sujet végétal sculptural (un olivier millénaire, un érable du Japon au feuillage flamboyant ou un pin taillé en nuage) dans l'axe d'une baie vitrée ou d'un couloir de circulation, l'extérieur devient un élément décoratif dynamique évoluant au fil des saisons.",
          "*« Un jardin bien pensé ne se contemple pas seulement quand on y marche ; il habite la maison chaque jour de l'année. »*",
        ],
      },
      {
        heading: "4. L'éclairage scénographique : Fusionner les espaces de nuit",
        paragraphs: [
          "À la tombée du jour, si le jardin s'éteint, la baie vitrée se transforme en un miroir noir, refermant visuellement le salon sur lui-même. Un éclairage paysager bien étudié permet de conserver cette sensation d'espace même au cœur de la nuit.",
          "En éclairant avec sobriété des éléments cibles du jardin (un massif de graminées, un tronc d'arbre, un mur en pierre sèche), vous étirez la profondeur de champ depuis votre canapé. Privilégiez des lumières rasantes et chaudes (2700K à 3000K) pour préserver la magie du lieu sans éblouir.",
        ],
        image: {
          src: "/assets/images/continuite-interieur-jardin-eclairage-nuit.jpg",
          caption: "Le jardin mis en scène par la lumière, à la tombée de la nuit",
        },
      },
      {
        heading: "Concevoir votre projet In & Out avec le Studio",
        paragraphs: [
          "Que ce soit pour la restructuration d'un appartement avec terrasse à Paris ou la conception d'une résidence principale, l'alliance de l'architecture d'intérieur et du design paysager est la clé d'un habitat d'exception.",
          "**Vous rêvez d'un lieu où l'intérieur et le jardin ne font qu'un ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour en discuter, ou [contactez-nous](/contact) pour nous présenter votre projet.",
        ],
      },
    ],
    keywords: ["Architecture In & Out", "Continuité intérieur extérieur", "Design paysager"],
    relatedProjects: ["giardino-de-ninno"],
  },
  {
    slug: "comment-vegetaliser-terrasse-rooftop-urbain-paris",
    title: "Comment végétaliser un rooftop ou une terrasse urbaine à Paris ?",
    metaTitle: "Aménager une Terrasse ou un Rooftop à Paris : Guide Design & Paysage",
    excerpt:
      "Comment végétaliser et aménager une terrasse ou un rooftop urbain à Paris ? Contraintes techniques, choix des plantes et mobilier sur-mesure.",
    date: "2026-06-16",
    category: "Design Paysager & Espaces Urbains",
    cover: "/assets/images/rooftop-vegetalise-paris-tour-eiffel.png",
    heroImage: "/assets/images/rooftop-vegetalise-paris-tour-eiffel.png",
    readingTime: "5 min",
    intro:
      "En milieu urbain, disposer d'une terrasse ou d'un rooftop est un privilège rare. Transformer ces mètres carrés en ciel ouvert en de véritables pépites végétales suspendues exige toutefois une maîtrise rigoureuse des contraintes techniques, climatiques et esthétiques.",
    sections: [
      {
        heading: "Les enjeux d'un aménagement paysager en hauteur",
        paragraphs: [
          "Aménager un rooftop à Paris ou dans une métropole ne s'improvise pas. Contrairement à un jardin en pleine terre, les espaces extérieurs en étage sont soumis à des contraintes structurelles strictes (charge au m², prise au vent, exposition solaire intense) et nécessitent des solutions sur-mesure.",
        ],
        image: {
          src: "/assets/images/rooftop-vegetalise-paris-tour-eiffel.png",
          caption: "Rooftop végétalisé avec vue sur la tour Eiffel",
        },
      },
      {
        heading: "1. Valider les contraintes techniques et de charge",
        paragraphs: [
          "Avant toute esquisse paysagère, l'étude de faisabilité technique est indispensable :",
          "**La capacité portante de la dalle :** déterminer le poids maximal autorisé au m² (terre saturée d'eau, jardinières, mobilier et usagers). Cette analyse conditionne le choix des bacs et de la densité des substrats.",
          "**L'étanchéité et l'évacuation des eaux :** préserver le support d'origine en intégrant des systèmes de drainage performants et des plots réglables sous le platelage.",
          "**La résistance au vent :** en hauteur, les vents sont amplifiés. Les structures (pergolas, claustras, arbres en bacs) doivent être ancrées et haubanées en toute sécurité.",
        ],
      },
      {
        heading: "2. Créer une bulle d'intimité sans occulter la vue",
        paragraphs: [
          "Le principal défi d'une terrasse parisienne réside dans la gestion des vis-à-vis tout en préservant les perspectives ouvertes sur la ville.",
          "Pour y parvenir, privilégiez un écran végétal dynamique plutôt qu'un mur occultant rigide. L'association de bambous non traçants (Fargesia), de graminées hautes (Miscanthus, Stipa) et d'arbustes à feuillage persistant crée un filtre végétal léger qui bouge sous la brise et préserve votre intimité avec élégance.",
        ],
        image: {
          src: "/assets/images/rooftop-bordeaux-vue-cathedrale.png",
          caption: "Bacs sur-mesure et vue sur les toits de Bordeaux",
        },
      },
      {
        heading: "3. Sélectionner une palette végétale résiliente et esthétique",
        paragraphs: [
          "Sur un rooftop, les plantes sont exposées à un microclimat exigeant : fort ensoleillement l'été, vent asséchant et volume de terre limité. Le choix des essences doit donc allier robustesse et beauté intemporelle.",
          "**Les feuillages persistants et structurants :** faux jasmin (Trachelospermum jasminoides) pour ses fleurs odorantes et son feuillage vert sombre, pins pignons nains, ou myrtes.",
          "**Les vivaces et graminées légères :** gauras, lavandes, sauges arbustives et pennisetums qui apportent du mouvement et de la légèreté.",
          "**L'arrosage automatique goutte-à-goutte :** équipement indispensable pour garantir la pérennité des plantations sans gaspillage d'eau.",
        ],
      },
      {
        heading: "4. Menuiseries sur-mesure et aménagement extérieur",
        paragraphs: [
          "Pour optimiser chaque mètre carré, le recours au sur-mesure est la clé. Dessiner des bacs en aluminium thermolaqué ou en acier corten intégrés aux garde-corps permet de maximiser l'espace au sol.",
          "L'intégration de bancs coffres en bois imputrescible (Ipé ou Kebony), d'une cuisine d'été discrète et d'un ombrage rétractable transforme la terrasse en une véritable pièce de vie supplémentaire, utilisable du printemps à l'automne.",
        ],
        image: {
          src: "/assets/images/rooftop-rome-cuisine-ete-colisee.png",
          caption: "Cuisine d'été et pergola sur-mesure, rooftop à Rome",
        },
      },
      {
        heading: "Confiez votre rooftop aux experts du Studio",
        paragraphs: [
          "De la vérification des autorisations copropriété/urbanisme jusqu'à la plantation des dernières essences, notre équipe conçoit des terrasses d'exception sur-mesure.",
          "**Vous rêvez d'un rooftop ou d'une terrasse végétalisée sur-mesure ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour étudier la faisabilité de votre projet, ou [contactez-nous](/contact) pour nous en dire plus.",
        ],
      },
    ],
    keywords: ["Rooftop Paris", "Terrasse végétalisée", "Design paysager urbain"],
    relatedProjects: ["giardino-de-ninno"],
  },
  {
    slug: "renovation-appartement-ancien-patrimoine-contemporain",
    title: "Rénovation d'un appartement ancien : Réussir l'alliance du patrimoine et du contemporain",
    metaTitle: "Rénovation d'Appartement Ancien : Allier Patrimoine et Modernité",
    excerpt:
      "Comment rénover un appartement haussmannien ou ancien à Paris ? Conservation des moulures, agencement contemporain et matériaux nobles.",
    date: "2026-07-14",
    category: "Rénovation & Architecture d'Intérieur",
    cover: "/assets/images/renovation-appartement-ancien-salon-cheminee-marbre-paris.jpg",
    readingTime: "5 min",
    intro:
      "Parquets Point de Hongrie, moulures sculptées, cheminées en marbre et belles hauteurs sous plafond : le charme de l'ancien demeure une valeur sûre. Comment sublimer cet héritage architectural tout en l'adaptant aux modes de vie contemporains ?",
    sections: [
      {
        heading: "Sublimer l'histoire sans la figer",
        paragraphs: [
          "Rénover un appartement haussmannien ou ancien nécessite un équilibre délicat. Il ne s'agit ni de transformer le lieu en musée nostalgique, ni de gommer son histoire par un minimalisme froid. L'enjeu est de faire dialoguer le vocabulaire classique avec des lignes architecturales sur-mesure, épurées et fonctionnelles.",
        ],
      },
      {
        heading: "1. Restaurer et mettre en valeur les éléments d'origine",
        paragraphs: [
          "Avant d'insérer des éléments contemporains, la première étape d'un projet de rénovation réussi réside dans la sauvegarde de l'existant :",
          "**Les parquets anciens :** conservation, ponçage à blanc et protection par des huiles mat ou des vernis invisibles pour restaurer la patine d'origine.",
          "**Les moulures et stucs :** réparation artisanale des ornements en plâtre endommagés par le temps ou les anciennes cloisons.",
          "**Les cheminées et miroirs dorés :** restauration du marbre et intégration comme pièces maîtresses dans la nouvelle scénographie.",
        ],
        image: {
          src: "/assets/images/renovation-appartement-haussmannien-chantier-moulures-paris.jpg",
          caption: "Chantier de restauration d'un appartement ancien, moulures et parquet Point de Hongrie",
        },
      },
      {
        heading: "2. Redéfinir les volumes pour la vie d'aujourd'hui",
        paragraphs: [
          "Les appartements du XIXe siècle étaient conçus selon une distribution très cloisonnée (enfilade de salons, pièces de service isolées). La rénovation contemporaine vise à réintroduire de la fluidité et de la clarté.",
          "L'ouverture de grands espaces de vie (séjour/cuisine) se fait grâce à la dépose de cloisons non porteuses ou à la création d'ouvertures sous IPN. Pour conserver la mémoire des pièces d'origine, on conserve au plafond les retombées de moulures qui marquent subtilement les anciennes limites.",
        ],
        image: {
          src: "/assets/images/renovation-appartement-ancien-salon-cheminee-marbre-paris.jpg",
          caption: "Salon rénové : cheminée en marbre et parquet Point de Hongrie restaurés",
        },
      },
      {
        heading: "3. La menuiserie sur-mesure comme trait d'union",
        paragraphs: [
          "L'insertion d'agencements sur-mesure au design très épuré (bibliothèques intégrées, dressing toute hauteur, îlots de cuisine minéraux) offre un contraste saisissant et élégant avec l'enveloppe classique.",
          "En dessinant des meubles qui s'alignent parfaitement avec les soubassements ou qui s'arrêtent à quelques centimètres des moulures sans jamais les étouffer, on crée un dialogue harmonieux entre le savoir-faire ébéniste d'aujourd'hui et l'artisanat d'autrefois.",
        ],
        image: {
          src: "/assets/images/renovation-appartement-ancien-cuisine-ilot-marbre-paris.jpg",
          caption: "Îlot de cuisine minéral intégré dans une rénovation d'appartement ancien",
        },
      },
      {
        heading: "4. Moderniser le confort technique en toute discrétion",
        paragraphs: [
          "L'un des plus grands défis de l'architecture d'intérieur dans l'ancien concerne l'intégration des équipements modernes sans altérer l'esthétique :",
          "**Passage encastré des réseaux électriques et de plomberie.**",
          "**Intégration de climatisations invisibles ou de réseaux de ventilation gainés dans des faux-plafonds partiels.**",
          "**Scénographie lumineuse combinant éclairage d'ambiance indirect (gorges lumineuses) et spots orientables discrets pour mettre en valeur les hauteurs.**",
        ],
      },
      {
        heading: "Votre projet de rénovation avec notre Studio",
        paragraphs: [
          "Notre studio d'architecture d'intérieur accompagne les propriétaires exigeants dans la restructuration globale et la valorisation d'appartements d'exception.",
          "**Vous souhaitez rénover un appartement ancien ou haussmannien ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une première visite conseil, ou [contactez-nous](/contact) pour en discuter.",
        ],
      },
    ],
    keywords: ["Rénovation appartement ancien", "Appartement haussmannien", "Patrimoine architectural"],
    relatedProjects: ["brasserie", "casa-duy"],
  },
  {
    slug: "cuisine-ouverte-haut-de-gamme-agencement-sur-mesure",
    title: "Cuisine ouverte sur-mesure : L'art de l'intégrer dans une pièce de vie haut de gamme",
    metaTitle: "Cuisine Ouverte Haut de Gamme : Agencement & Luxe Sur-Mesure",
    excerpt:
      "Comment intégrer une cuisine ouverte sur-mesure dans une pièce de vie haut de gamme ? Matériaux nobles, îlot central minéral et électroménager invisible.",
    date: "2026-07-07",
    category: "Architecture d'Intérieur & Agencement",
    cover: "/assets/images/cuisine-ouverte-sur-mesure-salon-vue-paris.jpg",
    readingTime: "5 min",
    intro:
      "Longtemps reléguée aux fonctions purement techniques, la cuisine s'impose désormais comme le cœur battant de l'habitat contemporain. Lorsqu'elle s'ouvre sur le séjour, l'enjeu architectural consiste à effacer son caractère utilitaire pour en faire un objet de design d'exception, parfaitement intégré au vocabulaire de la pièce de vie.",
    sections: [
      {
        heading: "Redéfinir la cuisine : Du fonctionnel à la pièce maîtresse",
        paragraphs: [
          "Dans une rénovation résidentielle haut de gamme, ouvrir la cuisine ne signifie pas simplement abattre un mur. C'est repenser l'équilibre visuel, la gestion des odeurs et du bruit, ainsi que la circulation globale. La cuisine doit savoir se faire discrète lors des réceptions tout en offrant un confort d'usage absolu au quotidien.",
        ],
      },
      {
        heading: "1. L'îlot central monolithique : Sculpture minérale et point de rassemblement",
        paragraphs: [
          "L'îlot central est la pièce maîtresse de la cuisine ouverte. Pour préserver l'élégance du séjour, le parti pris architectural s'oriente vers des formes affirmées et des matières d'exception.",
          "**Les blocs de pierre naturelle :** marbre de Calacatta, quartzite ou travertin adouci façonnés en monobloc. La continuité du veinage sur les retombées en cascade apporte une dimension sculpturale.",
          "**Le dialogue avec le mobilier d'art :** l'îlot ne doit plus ressembler à un meuble technique, mais répondre aux lignes de la table à manger ou du buffet du salon.",
          "**Les fonctions dissimulées :** plaques d'induction à aspiration intégrée à la table de cuisson pour supprimer la hotte suspendue traditionnelle et libérer totalement les perspectives visuelles.",
        ],
        image: {
          src: "/assets/images/cuisine-ouverte-piece-de-vie-salon-rome.jpg",
          caption: "L'îlot de cuisine en dialogue avec le mobilier de la pièce de vie",
        },
      },
      {
        heading: "2. Le concept de « Cuisine Invisible » : Agencements toute hauteur",
        paragraphs: [
          "Pour fondre la cuisine dans le décor de l'appartement ou de la maison, la menuiserie sur-mesure joue un rôle prépondérant.",
          "Le principe des **façades à portes escamotables (système à galandage)** permet de dissimuler l'électroménager, la zone de lavage et le petit électroménager derrière de grands panneaux toute hauteur en bois noble (chêne fumé, noyer d'Amérique, laque satinée). Une fois les portes fermées, la cuisine s'efface complètement au profit d'un mur d'agencement épuré.",
        ],
      },
      {
        heading: "3. Matériaux nobles et transition de sol",
        paragraphs: [
          "Pour réussir la jonction entre le séjour et la cuisine :",
          "**L'harmonie des sols :** soit en prolongeant le parquet en point de Hongrie dans la zone cuisine grâce à des traitements de surface haute résistance, soit en créant un calepinage sur-mesure en incrustant une pierre naturelle ou un terrazzo dans le bois.",
          "**La crédence comme œuvre d'art :** utilisation de laiton brossé, de miroir vieilli à la feuille ou de céramique artisanale pour refléter la lumière du séjour.",
        ],
        image: {
          src: "/assets/images/cuisine-ouverte-bois-sur-mesure-famille.jpg",
          caption: "Matériaux nobles et bois sur-mesure dans une cuisine ouverte familiale",
        },
      },
      {
        heading: "4. Éclairage : Passer du mode préparation au mode réception",
        paragraphs: [
          "L'éclairage d'une cuisine ouverte doit être modulable :",
          "**Un éclairage fonctionnel ciblé :** rubans LED invisibles intégrés sous les meubles hauts pour éclairer le plan de travail de manière homogène.",
          "**Un éclairage d'ambiance théâtral :** suspensions design au-dessus de l'îlot et spots encastrés basse luminance pour créer une atmosphère chaleureuse et intimiste dès que le repas est servi.",
        ],
        image: {
          src: "/assets/images/cuisine-ouverte-sur-mesure-salon-vue-paris.jpg",
          caption: "Cuisine ouverte en mode réception, à la tombée du jour",
        },
      },
      {
        heading: "Votre projet d'agencement sur-mesure avec le Studio",
        paragraphs: [
          "Chaque cuisine dessinée par notre studio est une création unique, conçue sur-mesure en collaboration avec nos artisans ébénistes et marbriers.",
          "**Vous imaginez une cuisine ouverte sur-mesure pour votre pièce de vie ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour en discuter, ou [contactez-nous](/contact) pour nous présenter votre projet.",
        ],
      },
    ],
    keywords: ["Cuisine ouverte sur-mesure", "Agencement haut de gamme", "Îlot central marbre"],
    relatedProjects: ["maison-kleber", "casa-duy"],
  },
  {
    slug: "suite-parentale-haut-de-gamme-dressing-salle-de-bains",
    title: "Concevoir une suite parentale d'exception : L'alliance du confort et du sur-mesure",
    metaTitle: "Concevoir une Suite Parentale d'Exception : Luxe, Dressing & Bains",
    excerpt:
      "Comment aménager une suite parentale haut de gamme ? Organisation de l'espace, dressing sur-mesure et salle de bains d'hôtel particulier.",
    date: "2026-06-23",
    category: "Architecture d'Intérieur & Espaces Privés",
    cover: "/assets/images/suite-parentale-dressing-sur-mesure-baignoire-ilot.jpg",
    readingTime: "5 min",
    intro:
      "Véritable sanctuaire privé au cœur de l'habitat, la suite parentale a profondément évolué. Loin de la simple chambre avec salle d'eau attenante, elle est aujourd'hui pensée comme une suite d'hôtel particulier : un espace fluide et intime regroupant nuit, dressing sur-mesure et salle de bains bien-être.",
    sections: [
      {
        heading: "Repenser la suite parentale comme un espace fluide",
        paragraphs: [
          "L'agencement d'une suite parentale réussie repose sur la circulation. Les frontières s'allègent : les portes battantes traditionnelles s'effacent au profit de claustras en bois, de verrières en métal patiné ou de cloisons japonaises coulissantes, permettant à la lumière de traverser toute la profondeur du volume.",
        ],
        image: {
          src: "/assets/images/suite-parentale-chambre-parisienne-salle-de-bain-marbre.jpg",
          caption: "Suite parentale parisienne, chambre et salle de bains en marbre",
        },
      },
      {
        heading: "1. La tête de lit architecturale : Élément fondateur de la chambre",
        paragraphs: [
          "Dans la zone nuit, la tête de lit dessinée par l'architecte d'intérieur structure la pièce :",
          "**Intégration multi-fonctions :** elle intègre dans une même composition en menuiserie les chevets suspendus, les liseuses encastrées, les prises invisibles et les niches d'exposition.",
          "**Matières enveloppantes :** utilisation de panneaux en bois cannelé, de velours tendus acoustiques ou de peintures à la chaux pour apporter du relief et une sensation de cocon apaisant.",
        ],
      },
      {
        heading: "2. Le dressing sur-mesure : L'élégance de la haute couture",
        paragraphs: [
          "Un dressing haut de gamme ne se contente pas de ranger : il met en scène la garde-robe.",
          "**Menuiseries intérieures :** utilisation d'essences de bois chaleureuses (noyer, frêne teinté) associées à des inserts en cuir ou en suédine dans les tiroirs d'accessoires.",
          "**Jeux de transparence :** façades en verre teinté vitré avec structures aluminium ultra-fines pour laisser deviner les pièces sans charger visuellement l'espace.",
          "**Mise en lumière intégrée :** éclairage LED indirect à détection de présence sous chaque étagère pour un confort visuel digne des plus grandes maisons de luxe.",
        ],
        image: {
          src: "/assets/images/suite-parentale-dressing-sur-mesure-baignoire-ilot.jpg",
          caption: "Dressing sur-mesure et salle de bains ouverte, suite parentale",
        },
      },
      {
        heading: "3. La salle de bains : Une expérience spa à domicile",
        paragraphs: [
          "La salle de bains de la suite parentale devient un lieu de ressourcement.",
          "**Baignoire îlot sculpturale ou douche à l'italienne XXL :** intégration de receveurs affleurants en pierre naturelle avec banc maçonné et ciel de pluie encastré au plafond.",
          "**Matériaux minéraux et durables :** terrazzo grand format, travertin adouci, robinetterie encastrée en finition bronze ou laiton brossé.",
          "**Gestion de la ventilation et de la lumière :** intégration discrète des équipements techniques et valorisation de la lumière naturelle par des verrières dépolies ou du verre strié.",
        ],
        image: {
          src: "/assets/images/suite-parentale-salle-de-bain-terre-cuite-douche-italienne.jpg",
          caption: "Douche à l'italienne et matériaux naturels, salle de bains suite parentale",
        },
      },
      {
        heading: "Créer votre cocon privé avec notre Studio",
        paragraphs: [
          "De la redistribution des volumes jusqu'au choix du moindre textile, notre équipe d'architectes d'intérieur conçoit des suites parentales d'exception adaptées à votre rythme de vie.",
          "**Vous rêvez d'une suite parentale sur-mesure ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour en discuter, ou [contactez-nous](/contact) pour nous présenter votre projet.",
        ],
      },
    ],
    keywords: ["Suite parentale", "Dressing sur-mesure", "Salle de bains luxe"],
    relatedProjects: ["maison-kleber", "casa-duy"],
  },
  {
    slug: "renovation-globale-appartement-maison-architecture-interieur",
    title: "Rénovation globale d'exception : Redessiner l'art de vivre et valoriser le patrimoine",
    metaTitle: "Rénovation Globale d'Appartement & Maison : Guide d'Architecture d'Intérieur",
    excerpt:
      "Comment aborder la rénovation globale et la restructuration complète d'un bien d'exception ? Processus, redistribution des volumes et valeur patrimoniale.",
    date: "2026-07-21",
    category: "Rénovation & Architecture d'Intérieur",
    cover: "/assets/images/renovation-globale-chantier-restructuration-appartement.jpg",
    readingTime: "6 min",
    intro:
      "S'engager dans la rénovation globale d'un appartement ou d'une maison d'exception dépasse la simple remise au goût du jour. C'est l'opportunité de repenser intégralement l'expérience de l'habitat, d'adapter un lieu à un mode de vie contemporain et d'en pérenniser la valeur patrimoniale par des choix d'agencement et de matériaux exigeants.",
    sections: [
      {
        heading: "La rénovation globale : Une vision d'ensemble indispensable",
        paragraphs: [
          "Entreprendre des travaux pièce par pièce mène souvent à une fragmentation visuelle et technique. À l'inverse, la restructuration complète orchestrée par un architecte d'intérieur permet de poser un diagnostic global sur le bien : flux de circulation, apport de lumière naturelle, logique structurelle et cohérence esthétique d'un bout à l'autre de l'espace.",
        ],
      },
      {
        heading: "1. La redistribution des volumes : Libérer le potentiel spatial",
        paragraphs: [
          "Chaque lieu possède sa propre écriture architecturale. Le premier rôle de l'architecte d'intérieur consiste à lire cette structure d'origine pour en révéler tout le potentiel.",
          "**La rationalisation des espaces :** éliminer les mètres carrés perdus (couloirs sombres, dégagements superflus) pour agrandir les pièces de réception et créer des perspectives traversantes.",
          "**Le travail sur la lumière naturelle :** repenser l'orientation des fonctions selon la course du soleil, créer des verrières sur-mesure ou insérer des cloisons légères qui laissent filer le jour.",
          "**La hiérarchisation des zones :** marquer une séparation fluide mais claire entre les espaces de réception (salon, salle à manger, cuisine) et la sphère intime (chambres, dressing, suites).",
        ],
      },
      {
        heading: "2. L'intégration invisible de la technique et du confort",
        paragraphs: [
          "La marque d'une rénovation haut de gamme réside dans ce qui ne se voit pas. Les performances techniques s'intègrent de manière totalement imperceptible pour laisser toute la place à l'esthétique.",
          "**L'isolation et l'efficience énergétique :** amélioration des performances thermiques et acoustiques (doublages isolants hautes performances, menuiseries extérieures sur-mesure respectant les contraintes d'urbanisme).",
          "**La domotique et la scénographie lumineuse :** gestion centralisée des ambiances, dissimulation des réseaux électriques et intégration discrète d'éclairages indirects (gorges lumineuses, fentes encastrées).",
          "**Le confort climatique :** intégration invisible des systèmes de chauffage et de rafraîchissement d'air au sein des faux-plafonds ou des menuiseries d'agencement.",
        ],
      },
      {
        heading: "3. La continuité des matières : Créer une signature visuelle unifiée",
        paragraphs: [
          "Pour offrir une sensation d'apaisement et d'harmonie globale, le choix des matériaux répond à un fil conducteur rigoureux.",
          "Plutôt que d'accumuler des effets de style différents dans chaque pièce, la rénovation globale privilégie une palette restreinte de matières nobles et intemporelles — parquets en bois massif, enduits à la chaux, pierres naturelles, laiton brossé — déclinée avec subtilité à travers l'ensemble du projet.",
        ],
      },
      {
        heading: "4. De l'esquisse au suivi de chantier : La maîtrise d'œuvre rigoureuse",
        paragraphs: [
          "Mener à bien une rénovation complète exige une méthode d'accompagnement éprouvée :",
          "**Phase de conception (APS/APD) :** plans 2D, modélisations 3D, choix des matériaux et chiffrage détaillé.",
          "**Consultation et sélection des artisans :** mobilisation d'un réseau de compagnons et d'entreprises qualifiées pour chaque corps d'état.",
          "**Maîtrise d'œuvre et suivi de chantier :** coordination rigoureuse des plannings, contrôle de la qualité d'exécution et respect des engagements budgétaires jusqu'à la livraison clé en main.",
        ],
        image: {
          src: "/assets/images/renovation-globale-suivi-chantier-artisans-cuisine.jpg",
          caption: "Suivi de chantier et coordination des artisans, rénovation globale",
        },
      },
      {
        heading: "Confier votre projet de rénovation globale au Studio",
        paragraphs: [
          "Que vous veniez d'acquérir un bien à restructurer ou que vous souhaitiez métamorphoser votre résidence actuelle, notre agence d'architecture d'intérieur conçoit des projets sur-mesure façonnés pour durer.",
          "**Vous avez un projet de rénovation globale ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une première visite conseil, ou [contactez-nous](/contact) pour en discuter.",
        ],
        image: {
          src: "/assets/images/renovation-globale-maitrise-oeuvre-architecte-client.jpg",
          caption: "Une relation de confiance entre l'architecte et le client, du premier échange à la livraison",
        },
      },
    ],
    keywords: ["Rénovation globale", "Restructuration appartement", "Maîtrise d'œuvre"],
    relatedProjects: ["casa-duy", "maison-kleber"],
  },
  {
    slug: "vision-architecturale-volumes-lumiere-matiere",
    title: "Sculpter l'espace : Quand la vision architecturale transcende l'intérieur",
    metaTitle: "L'Architecture d'Intérieur : Sculpture des Volumes, Lumière & Matière",
    excerpt:
      "Comment la vision architecturale transforme un espace ? Découvrez l'art de sculpter les volumes, d'apprivoiser la lumière et d'orchestrer les matières nobles.",
    date: "2026-06-09",
    category: "Vision & Architecture d'Intérieur",
    cover: "/assets/images/architecture-interieur-volumes-lumiere-escalier-suspendu.jpg",
    readingTime: "6 min",
    intro:
      "Au-delà de l'agencement et de l'ameublement, l'architecture d'intérieur s'attache à la substance même du lieu. Elle n'habille pas des pièces existantes : elle orchestre les vides, façonne les volumes et capture la lumière pour créer des lieux de vie qui suscitent une émotion durable.",
    sections: [
      {
        heading: "1. La volumétrie : Jouer avec les pleins et les vides",
        paragraphs: [
          "Chaque projet d'architecture commence par une lecture tridimensionnelle de l'espace. Avant même d'envisager la moindre couleur, l'enjeu est de définir des proportions justes.",
          "**La verticalité et la hauteur sous plafond :** valoriser les volumes par des éléments verticaux toute hauteur (portes toute hauteur sans imposte, menuiseries intégrées, claustras géométriques) qui étirent le regard.",
          "**Le travail du vide :** savoir préserver des espaces d'air et de respiration. Dans une architecture contemporaine haut de gamme, le vide n'est pas un manque, mais un élément de composition à part entière qui met en valeur les pièces maîtresses.",
          "**Les perspectives et alignements :** créer des enfilades visuelles et des axes de fuite clairs qui traversent l'appartement ou la maison de part en part.",
        ],
        image: {
          src: "/assets/images/architecture-interieur-volumes-lumiere-escalier-suspendu.jpg",
          caption: "Escalier suspendu et puits de lumière, jeu de volumes architecturaux",
        },
      },
      {
        heading: "2. La lumière comme matériau de construction",
        paragraphs: [
          "La lumière n'est pas un simple apport fonctionnel ; c'est le matériau le plus vivant de l'architecte. Elle révèle les textures, transforme les teintes au fil des heures et rythme la journée.",
          "**La captation du jour :** repenser les ouvertures, utiliser des verrières architecturales sur-mesure ou du verre texturé pour diffuser une lumière douce dans les zones aveugles.",
          "**L'éclairage architectural nocturne :** bannir le point lumineux central unique au profit d'une scénographie lumineuse invisible. L'intégration de gorges lumineuses, de fentes encastrées et de spots basse luminance permet de sculpter les formes dès le crépuscule.",
        ],
        image: {
          src: "/assets/images/architecture-interieur-matiere-cuisine-travertin-oliviers.jpg",
          caption: "La lumière naturelle sublime la matière, cuisine ouverte sur une oliveraie",
        },
      },
      {
        heading: "3. La vérité de la matière : L'éloge du brut et du noble",
        paragraphs: [
          "L'architecture contemporaine s'éloigne des artifices pour célébrer la noblesse des matières texturées et pérennes.",
          "L'association de surfaces minérales (pierre naturelle adoucie, béton architectonique, enduits à la chaux ou à l'argile) et de touches chaleureuses (bois massif, laiton patiné, textiles en lin brut) crée une tension visuelle élégante. Ce contraste apporte à l'intérieur une présence tactile et une patine qui s'embellit avec le temps.",
        ],
        image: {
          src: "/assets/images/architecture-interieur-matiere-travertin-salle-de-bain.jpg",
          caption: "Pierre naturelle et matières nobles, salle de bains contemporaine",
        },
      },
      {
        heading: "4. L'intégration invisible du détail technique",
        paragraphs: [
          "Ce qui distingue une approche architecturale rigoureuse d'un simple aménagement, c'est le soin porté au détail d'exécution :",
          "**Les plinthes à effleurage :** intégrées au nu du mur pour une pureté de ligne absolue.",
          "**Les portes à galandage et châssis invisibles :** sans encadrement apparent (système Filomuro), permettant aux cloisons de se présenter comme de purs plans de masse.",
          "**Le calepinage millimétré :** l'alignement parfait des joints de carrelage, des dalles de pierre et des calepinages de bois pour une harmonie géométrique parfaite.",
        ],
      },
      {
        heading: "Faire dialoguer votre lieu avec l'architecture avec le Studio",
        paragraphs: [
          "Notre studio aborde chaque projet avec la rigueur de l'architecte et la sensibilité du designer, pour bâtir des espaces sur-mesure où chaque détail trouve sa justification.",
          "**Vous avez une vision pour votre espace ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour en discuter, ou [contactez-nous](/contact) pour nous présenter votre projet.",
        ],
      },
    ],
    keywords: ["Architecture d'intérieur", "Volumes et lumière", "Matériaux nobles"],
    relatedProjects: ["maison-kleber", "giardino-de-ninno"],
  },
  {
    slug: "materiaux-biosources-architecture-durable-interieur-paysage",
    title:
      "Les matériaux biosourcés en architecture : concevoir des espaces durables, sains et esthétiques",
    metaTitle:
      "Matériaux Biosourcés en Architecture : Espaces Durables et Sains",
    excerpt:
      "Bois, chanvre, paille, liège : comment les matériaux biosourcés transforment l'architecture, l'aménagement intérieur et le paysage vers plus de sobriété et de sensibilité.",
    date: "2026-08-06",
    category: "Matériaux & Éco-conception",
    cover: "/assets/images/salon-materiaux-biosources-bois-pierre-paris.png",
    readingTime: "6 min",
    intro:
      "Face aux enjeux environnementaux actuels, l'architecture évolue vers des pratiques plus responsables, intégrant davantage de matériaux naturels et renouvelables dans la conception des bâtiments, des espaces intérieurs et des jardins. Chez Supra Studio, nous considérons les matériaux biosourcés comme une véritable opportunité architecturale : ils permettent de créer des lieux plus sensibles, plus durables et davantage connectés à leur environnement.",
    sections: [
      {
        heading: "Qu'est-ce qu'un matériau biosourcé ?",
        paragraphs: [
          "Un matériau biosourcé est un matériau issu en partie ou totalement de ressources renouvelables provenant du vivant : végétaux, animaux ou sous-produits agricoles. Contrairement aux matériaux conventionnels issus principalement de ressources fossiles ou minérales, il participe au développement d'une architecture plus circulaire en valorisant des matières naturelles disponibles.",
          "Parmi les plus utilisés en architecture, on retrouve le bois et ses dérivés, la paille, le chanvre, le liège, la fibre de bois, le lin, la laine de mouton, la ouate de cellulose, ainsi que les enduits naturels à base de terre ou de chaux. Ces matériaux peuvent être employés aussi bien dans la structure d'un bâtiment que dans son isolation, son aménagement intérieur ou ses espaces paysagers.",
        ],
      },
      {
        heading: "Le bois, un matériau architectural intemporel",
        paragraphs: [
          "Le bois est probablement le matériau biosourcé le plus connu et le plus utilisé dans la construction. Grâce à ses qualités mécaniques, son faible impact carbone et son aspect chaleureux, il trouve sa place dans de nombreux projets contemporains : ossature, charpente, bardage extérieur, menuiseries, mobilier sur mesure, aménagements intérieurs.",
          "Au-delà de ses performances techniques, le bois apporte une dimension sensible à l'architecture. Sa texture, son vieillissement naturel et ses variations de teintes créent des espaces vivants et authentiques. Dans une approche architecturale globale, le choix de l'essence, de son origine et de sa mise en œuvre devient un véritable parti pris esthétique.",
        ],
        image: {
          src: "/assets/images/salon-materiaux-biosources-bois-pierre-paris.png",
          caption:
            "Salon parisien associant bois massif, pierre naturelle et terre cuite, Supra Studio",
        },
      },
      {
        heading: "Le chanvre et la paille : des isolants naturels performants",
        paragraphs: [
          "Les isolants biosourcés connaissent aujourd'hui un fort développement grâce à leurs performances thermiques et leur capacité à améliorer le confort intérieur. Le chanvre, par exemple, offre une bonne régulation naturelle de l'humidité, une isolation thermique efficace, un confort acoustique appréciable et un faible impact environnemental.",
          "La paille, souvent associée à une architecture écologique alternative, est également un matériau performant lorsqu'elle est correctement mise en œuvre. Elle permet de réaliser des bâtiments énergétiquement performants tout en valorisant une ressource agricole locale — la preuve qu'une architecture durable peut aussi être innovante et contemporaine.",
        ],
      },
      {
        heading:
          "Le bois, le liège et les fibres naturelles dans l'aménagement intérieur",
        paragraphs: [
          "L'utilisation des matériaux biosourcés ne concerne pas uniquement la construction : ils jouent également un rôle majeur en architecture intérieure. Les espaces intérieurs influencent directement notre perception du confort et de la qualité de vie, et les matériaux naturels permettent de créer des ambiances plus chaleureuses et intemporelles.",
          "Dans un projet d'architecture intérieure, ils s'intègrent à travers des agencements sur mesure en bois massif, des panneaux décoratifs en fibres naturelles, des revêtements en liège, des textiles naturels (lin, laine, chanvre) ou des peintures et enduits naturels. Ils apportent une richesse sensorielle particulière — toucher, matière, odeur, lumière — pour des intérieurs agréables à vivre sur le long terme, et pas seulement beaux à regarder.",
        ],
      },
      {
        heading:
          "Les matériaux naturels dans le paysage : reconnecter architecture et nature",
        paragraphs: [
          "L'approche biosourcée dépasse les limites du bâtiment et concerne également l'aménagement des espaces extérieurs. Dans un projet de paysage, le choix des matériaux influence fortement la relation entre architecture et environnement : terrasses en bois local, clôtures en bois non traité, mobilier extérieur en matériaux naturels, paillages végétaux, structures en fibres végétales, aménagements utilisant des ressources locales.",
          "L'objectif est de créer des espaces extérieurs qui s'intègrent naturellement dans leur contexte tout en limitant leur impact environnemental. Le paysage devient alors un prolongement de l'architecture, conçu avec la même attention portée aux matières et aux usages.",
        ],
        image: {
          src: "/assets/images/patio-terre-crue-pierre-naturelle-materiaux-biosources.png",
          caption:
            "Patio en terre crue et pierre naturelle, végétation méditerranéenne",
          afterParagraph: 1,
        },
      },
      {
        heading: "Réduire l'impact environnemental du projet",
        paragraphs: [
          "Les matériaux biosourcés contribuent à diminuer l'empreinte carbone des constructions grâce à leur origine renouvelable, à une capacité de stockage du carbone pour certains matériaux comme le bois, à une production souvent moins énergivore et à une valorisation des ressources locales. Ils participent ainsi à une démarche d'architecture plus responsable.",
        ],
      },
      {
        heading: "Améliorer le confort des habitants",
        paragraphs: [
          "Au-delà de l'aspect environnemental, les matériaux naturels améliorent également la qualité des espaces : meilleure régulation de l'humidité, confort thermique renforcé, qualité acoustique et atmosphère intérieure plus saine. L'architecture durable ne se limite donc pas à la performance énergétique : elle concerne aussi le bien-être quotidien des occupants.",
        ],
      },
      {
        heading: "Donner une identité unique au projet",
        paragraphs: [
          "Chaque matériau possède une histoire, une texture et une manière particulière de vieillir. Le choix de matériaux biosourcés permet de créer des espaces plus authentiques et moins standardisés. Dans une démarche d'architecture sur mesure, la matière devient un élément essentiel du projet, au même titre que la lumière, les volumes ou les usages.",
        ],
      },
      {
        heading: "Vers une architecture plus durable et plus sensible",
        paragraphs: [
          "L'utilisation des matériaux biosourcés représente une évolution majeure dans les métiers de l'architecture, de l'architecture intérieure et du paysage. Plus qu'une simple tendance écologique, ils offrent une nouvelle manière de concevoir les espaces : une architecture attentive aux ressources, aux usages et aux sensations.",
          "Chez Supra Studio, nous intégrons cette réflexion dans nos projets en recherchant un équilibre entre design contemporain, qualité des matériaux et respect de l'environnement. Une architecture durable n'est pas seulement une architecture qui consomme moins : c'est une architecture qui crée des lieux plus agréables, plus justes et plus durables dans le temps.",
          "**Vous portez un projet intégrant des matériaux naturels ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une première visite conseil, ou [contactez-nous](/contact) pour en discuter.",
        ],
      },
      {
        heading: "Questions fréquentes sur les matériaux biosourcés",
        paragraphs: [
          "**Quels sont les principaux matériaux biosourcés utilisés en architecture ?** Le bois, le chanvre, la paille, le liège, la fibre de bois, le lin, la laine de mouton et la ouate de cellulose.",
          "**Les matériaux biosourcés sont-ils adaptés à la rénovation ?** Oui : leurs qualités d'isolation, de régulation de l'humidité et leur capacité à améliorer le confort intérieur en font un choix particulièrement pertinent en rénovation.",
          "**Les matériaux biosourcés sont-ils plus chers ?** Le coût dépend du matériau choisi, de sa disponibilité et de sa mise en œuvre. Certains représentent un investissement initial supérieur, mais offrent souvent des bénéfices durables en termes de confort et de performance.",
          "**Peut-on utiliser des matériaux biosourcés dans un projet haut de gamme ?** Oui : ils sont aujourd'hui largement utilisés dans des projets premium grâce à leur qualité esthétique, leur authenticité et leur capacité à créer des espaces uniques.",
        ],
      },
    ],
    keywords: [
      "Matériaux biosourcés",
      "Architecture durable",
      "Éco-conception",
    ],
    relatedProjects: ["maison-kleber", "giardino-de-ninno"],
  },
  {
    slug: "prix-architecte-interieur-paris-m2-2026",
    title:
      "Prix d'un architecte d'intérieur à Paris au m² en 2026 : combien prévoir pour votre projet ?",
    metaTitle: "Prix Architecte d'Intérieur Paris au m² 2026 : Honoraires & Budget",
    excerpt:
      "Tarif horaire, forfait au m² ou pourcentage des travaux : les fourchettes de prix pratiquées à Paris en 2026 et les critères qui font varier le budget d'un projet à l'autre.",
    date: "2026-08-11",
    category: "Conseils & expertise",
    cover: "/assets/images/visite-technique-metre-laser-appartement-paris.png",
    readingTime: "7 min",
    intro:
      "Rénover un appartement à Paris soulève rapidement une question : combien coûte réellement l'intervention d'un architecte d'intérieur ? Entre tarif horaire, forfait au mètre carré et pourcentage du montant des travaux, les modes de facturation varient d'une agence à l'autre, ce qui rend la comparaison des devis difficile pour qui n'est pas familier du secteur. Chez Supra Studio, nous pensons qu'un budget clair, expliqué en amont, fait partie intégrante d'une relation de confiance avec nos clients.",
    sections: [
      {
        heading: "Le tarif horaire",
        paragraphs: [
          "Adapté à une prestation ponctuelle — un avis, une visite-conseil, la relecture d'un plan — le tarif horaire offre une transparence totale sur le temps passé par l'architecte. À Paris, il se situe généralement entre 100 € et 200 € HT de l'heure en 2026, selon l'expérience de l'agence et la complexité de la question posée. C'est la formule la plus flexible, mais aussi la plus difficile à anticiper si le besoin n'est pas clairement délimité au départ.",
        ],
      },
      {
        heading: "Le forfait au mètre carré pour la conception",
        paragraphs: [
          "Très répandu pour une mission de conception — plans, perspectives, sélection des matériaux — le forfait au m² permet de connaître le budget dès le lancement du projet. À Paris, il oscille en 2026 entre 90 € et 200 € par m² pour une conception seule, et peut grimper entre 150 € et 300 € par m² lorsque la mission inclut un dossier technique détaillé (plans d'exécution, coordination avec un bureau d'études). L'avantage de cette formule est sa prévisibilité : le montant est fixé avant le démarrage des travaux, quelle que soit la durée réelle de conception.",
        ],
        image: {
          src: "/assets/images/rendez-vous-architecte-interieur-devis-paris.png",
          caption: "Établissement d'un devis personnalisé lors d'une visite-conseil, Supra Studio",
        },
      },
      {
        heading: "Le pourcentage du montant des travaux",
        paragraphs: [
          "C'est le modèle de référence pour une rénovation pilotée de A à Z, avec suivi de chantier. Les honoraires sont alors calculés sur le montant total des devis des artisans (maçonnerie, électricité, plomberie, peinture, menuiserie). En 2026 à Paris, ce taux se situe le plus souvent entre 10 % et 15 % du montant des travaux HT, avec une dégressivité selon l'ampleur du chantier : autour de 12 à 15 % pour des travaux inférieurs à 100 000 €, 10 à 12 % entre 100 000 € et 200 000 €, et 7 à 10 % au-delà de 200 000 €. Cette méthode aligne la rémunération de l'architecte sur l'ampleur réelle du projet, mais suppose de bien anticiper le montant des travaux pour éviter les mauvaises surprises.",
        ],
      },
      {
        heading: "Combien prévoir concrètement ?",
        paragraphs: [
          "Pour donner un ordre de grandeur : une mission complète (conception, plans, suivi de chantier) pour un appartement parisien de 60 m² représente en 2026 un budget d'honoraires compris entre 8 000 € et 12 000 € HT, hors coût des travaux eux-mêmes. Pour une petite surface ou une mission de conseil ponctuel, le budget peut démarrer autour de 2 500 €. Pour la rénovation complète d'un grand appartement familial avec redistribution des volumes, il peut dépasser 20 000 €.",
          "Ces honoraires ne représentent toutefois qu'une partie du budget global d'un projet de rénovation. À Paris en 2026, le coût des travaux eux-mêmes varie fortement selon leur ampleur : un rafraîchissement simple (peintures, sols, petite plomberie) se situe autour de 300 € à 800 € par m², une rénovation standard sans gros œuvre entre 700 € et 1 400 € par m², et une rénovation lourde avec redistribution des cloisons, reprise de plomberie et création de nouveaux espaces entre 1 200 € et 2 500 € par m², voire davantage dans l'ancien haussmannien nécessitant une transformation complète. En intégrant honoraires d'architecte, coordination de chantier et assurances, le budget global d'un projet parisien bien accompagné se situe le plus souvent entre 1 400 € et 1 800 € par m².",
        ],
      },
      {
        heading: "Les facteurs qui font varier le prix",
        paragraphs: [
          "Plusieurs éléments expliquent pourquoi deux projets de surface comparable peuvent afficher des budgets très différents. L'état du bâti existant joue un rôle déterminant : un immeuble haussmannien à rénover en profondeur, avec des planchers déformés ou une plomberie ancienne à remplacer intégralement, coûte sensiblement plus cher à traiter qu'un appartement récent en bon état.",
          "L'étendue de la mission influence directement le budget d'honoraires : une simple visite-conseil n'a rien à voir avec une mission complète incluant la conception, le dépôt des autorisations et le suivi de chantier jusqu'à la livraison. La modification du plan a un coût spécifique : chaque mur déplacé implique une étude structurelle, une autorisation de copropriété, la dépose et la reprise, ce qui peut ajouter plusieurs milliers d'euros au budget global.",
          "Le règlement de copropriété peut également peser sur le calendrier, et donc sur le coût : des horaires de chantier restreints ou une interdiction de certains gros œuvres allongent la durée des travaux. Le niveau de finition recherché enfin fait varier le budget du simple au double : entre une peinture standard et un enduit à la chaux ou un béton ciré sur mesure, l'écart de prix est significatif — un choix qui relève autant de l'esthétique que du budget alloué au projet.",
        ],
      },
      {
        heading: "Comment nous établissons un budget chez Supra Studio",
        paragraphs: [
          "Chaque projet étant singulier, nous ne proposons pas de grille tarifaire figée. Notre première étape est toujours une visite-conseil sur place, qui nous permet d'évaluer l'état du bâti, la complexité technique du projet et l'ampleur réelle de la mission souhaitée — de la simple conception à l'accompagnement complet jusqu'à la livraison du chantier. Sur cette base, nous établissons un devis personnalisé et détaillé, avant tout engagement de votre part.",
          "Cette approche nous permet d'ajuster nos honoraires à la réalité de chaque lieu plutôt que d'appliquer un forfait générique — dans la continuité de notre conviction qu'un projet réussi se construit sur une lecture précise du bâti, avant toute question de budget.",
          "**Vous préparez un projet de rénovation à Paris ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une visite-conseil, ou [contactez-nous](/contact) pour en discuter.",
        ],
      },
      {
        heading: "Questions fréquentes",
        paragraphs: [
          "**Quel est le prix moyen d'un architecte d'intérieur à Paris en 2026 ?** Les honoraires se situent le plus souvent entre 90 € et 200 € par m² pour une mission de conception, ou entre 10 % et 15 % du montant des travaux pour une mission complète avec suivi de chantier.",
          "**Le prix dépend-il de la taille de l'appartement ?** Oui, mais pas de façon strictement proportionnelle : les coûts fixes d'un projet (démarches administratives, installation de chantier, coordination) se répartissent sur un plus grand nombre de m² dans les grandes surfaces, ce qui explique un prix au m² légèrement dégressif au-delà de 80-100 m².",
          "**Un petit budget permet-il de faire appel à un architecte d'intérieur ?** Oui. Une mission ponctuelle — visite-conseil, avis sur un plan, accompagnement partiel — reste accessible dès 2 500 € environ, et peut suffire à sécuriser les choix essentiels d'un projet sans mobiliser un budget d'honoraires complet.",
          "**Faut-il inclure le coût des travaux dans le budget de l'architecte ?** Non : les honoraires de conception et de suivi sont distincts du coût des travaux réalisés par les artisans. Il est essentiel de budgéter les deux séparément pour avoir une vision réaliste du coût total du projet. Pour une estimation détaillée du budget des travaux poste par poste, consultez notre article sur le [coût d'une rénovation d'appartement à Paris](/journal/cout-renovation-appartement-paris-budget-complet).",
          "**Comment sont concrètement calculés ces honoraires ?** Les modes de calcul (pourcentage des travaux, forfait, taux horaire, tarif au m²) et les critères à vérifier avant de signer un devis sont détaillés dans notre article sur les [honoraires d'un architecte d'intérieur à Paris](/journal/honoraires-architecte-interieur-paris).",
        ],
      },
    ],
    keywords: [
      "Prix architecte d'intérieur Paris",
      "Honoraires architecte d'intérieur",
      "Budget rénovation Paris",
    ],
    relatedProjects: ["casa-duy", "maison-kleber"],
  },
  {
    slug: "amenagement-studio-paris-optimiser-30m2",
    title: "Aménagement studio à Paris : comment bien optimiser 30 m² ?",
    metaTitle: "Aménagement Studio Paris 30 m² : Nos Conseils d'Architecte",
    excerpt:
      "Plan, lit escamotable ou mezzanine, cuisine compacte, rangements sur mesure : comment un studio parisien de 30 m² peut offrir un vrai confort de vie, sans jamais paraître à l'étroit.",
    date: "2026-08-18",
    category: "Architecture d'Intérieur & Agencement",
    cover: "/assets/images/studio-parisien-agencement-sur-mesure-cuisine-bureau.jpg",
    readingTime: "6 min",
    intro:
      "Un studio de 30 m² à Paris n'est pas un petit appartement : c'est un exercice de conception à part entière, où chaque mètre carré doit remplir plusieurs fonctions à la fois. Dormir, cuisiner, travailler, recevoir — dans un studio, toutes ces vies se déroulent dans la même pièce, parfois dans le même mètre carré selon l'heure de la journée. Bien aménagé, un studio de cette taille peut pourtant offrir un confort de vie réel, sans jamais donner l'impression d'être à l'étroit.",
    sections: [
      {
        heading: "Repenser le plan avant d'acheter le moindre meuble",
        paragraphs: [
          "La première erreur, dans un petit espace, est de commencer par le mobilier. Un studio bien pensé part au contraire d'une analyse du plan existant : où se trouve la lumière naturelle, quelles sont les contraintes techniques (arrivées d'eau, réseau électrique, murs porteurs), et quels usages doivent cohabiter dans la journée. Un studio de 30 m² accueille en réalité plusieurs \"pièces\" invisibles — un coin nuit, un coin repas, un coin travail, parfois un coin salon — qu'il faut organiser en séquence plutôt qu'en superposition.",
          "Cette réflexion de plan permet souvent de gagner plusieurs mètres carrés utiles sans toucher à la structure : déplacer une kitchenette de quelques dizaines de centimètres, orienter le lit différemment, ou redessiner la circulation entre l'entrée et la fenêtre peut transformer la perception de l'espace, bien avant toute question de décoration.",
        ],
      },
      {
        heading: "Le lit, poste stratégique du studio",
        paragraphs: [
          "Dans un studio, le lit occupe souvent le plus grand volume au sol — c'est donc le premier élément à repenser. Plusieurs solutions permettent de libérer l'espace qu'il occupe en journée : un lit escamotable intégré dans un caisson sur mesure, une mezzanine si la hauteur sous plafond le permet (généralement à partir de 2,50 m), ou un canapé-lit de qualité si le budget ou la configuration ne permettent pas d'installation fixe.",
          "La mezzanine reste la solution la plus radicale et la plus efficace en termes de mètres carrés regagnés : elle libère entièrement le sol pour un salon ou un bureau, au prix d'une hauteur sous plafond réduite pour dormir. Le lit escamotable, lui, offre un compromis intéressant dans les studios à plafond standard, à condition d'être intégré dans un agencement sur mesure qui dissimule le mécanisme et prolonge l'esthétique du reste de la pièce.",
        ],
        image: {
          src: "/assets/images/lit-escamotable-kitchenette-studio-paris.jpg",
          caption: "Lit escamotable intégré et kitchenette sur mesure, studio parisien, Supra Studio",
        },
      },
      {
        heading: "Une cuisine compacte, mais entièrement fonctionnelle",
        paragraphs: [
          "La kitchenette d'un studio n'a pas besoin d'être grande pour être efficace, mais elle doit être pensée avec la même rigueur qu'une cuisine ouverte de 20 m². Un agencement sur mesure permet d'exploiter chaque centimètre de linéaire, d'intégrer les appareils électroménagers à taille réduite sans perdre en fonctionnalité, et de dissimuler la cuisine derrière une façade coordonnée avec le reste de la pièce lorsqu'elle n'est pas utilisée — par exemple à l'aide de portes coulissantes ou d'un meuble fermé.",
          "Le choix des matériaux joue ici un rôle important : une même teinte ou un même matériau entre la façade de cuisine et les rangements adjacents permet à l'œil de percevoir un seul volume cohérent, plutôt qu'une accumulation d'éléments distincts, ce qui agrandit visuellement l'espace.",
        ],
      },
      {
        heading: "Des rangements sur mesure pour exploiter chaque recoin",
        paragraphs: [
          "Dans un studio, le rangement standard trouvé dans le commerce s'adapte rarement bien aux volumes disponibles — il laisse presque toujours des espaces perdus. L'agencement sur mesure permet au contraire d'exploiter des recoins autrement inutilisables : un renfoncement transformé en penderie, une hauteur sous plafond valorisée par des rangements en partie haute, un espace sous un lit surélevé converti en dressing ou en bureau.",
          "Les rangements toute hauteur, jusqu'au plafond, sont particulièrement efficaces dans un studio : ils multiplient la capacité de rangement sans ajouter d'emprise au sol, et leur ligne verticale continue donne également une impression de hauteur à la pièce.",
        ],
      },
      {
        heading: "Lumière, miroirs et continuité visuelle",
        paragraphs: [
          "Un studio bien aménagé se perçoit toujours plus grand qu'il ne l'est réellement — un effet obtenu autant par la lumière que par le plan. Privilégier une palette de teintes claires et continues entre les murs, les sols et le mobilier évite de fragmenter visuellement l'espace en plusieurs zones. Un miroir bien positionné, notamment face à la fenêtre, prolonge la lumière naturelle et donne une sensation de profondeur.",
          "La lumière artificielle mérite la même attention : plutôt qu'un plafonnier central unique, plusieurs sources de lumière basses et indirectes (appliques, lampadaires, éclairage intégré aux rangements) créent une ambiance plus chaleureuse et permettent de distinguer les différents usages de la pièce, même en l'absence de cloisons.",
        ],
      },
      {
        heading: "Une salle d'eau pensée au millimètre",
        paragraphs: [
          "Dans un studio, la salle d'eau est souvent la pièce la plus contrainte en surface. Un receveur de douche extra-plat plutôt qu'une baignoire, un meuble vasque suspendu pour libérer le sol visuellement, ou une paroi de douche vitrée plutôt qu'un rideau permettent de gagner en sensation d'espace sans sacrifier le confort d'usage. Comme pour la kitchenette, un agencement sur mesure permet d'utiliser l'intégralité du volume disponible, y compris les recoins les moins évidents.",
        ],
      },
      {
        heading: "Comment nous abordons un projet de studio chez Supra Studio",
        paragraphs: [
          "Un studio de 30 m² n'est jamais un \"petit projet\" au sens propre : c'est souvent l'exercice le plus exigeant en architecture intérieure, où chaque décision de plan a des répercussions sur l'ensemble de l'espace. Notre approche commence, comme pour tout projet, par une visite-conseil sur place, pour évaluer la configuration existante, la lumière, les contraintes techniques et les usages prioritaires du futur habitant. Nous concevons ensuite un plan et un agencement sur mesure — mobilier, rangements, cuisine, salle d'eau — pensés comme un ensemble cohérent plutôt que comme une succession de meubles achetés séparément.",
          "**Vous préparez l'aménagement d'un studio à Paris ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une visite-conseil, ou [contactez-nous](/contact) pour en discuter.",
        ],
      },
      {
        heading: "Questions fréquentes",
        paragraphs: [
          "**Quelle surface minimale pour installer une mezzanine dans un studio ?** Une mezzanine nécessite généralement une hauteur sous plafond d'au moins 2,50 m au point le plus haut, pour conserver une hauteur suffisante à la fois en dessous et au-dessus. En deçà, un lit escamotable ou un canapé-lit de qualité restent les solutions les plus adaptées.",
          "**Faut-il privilégier le sur-mesure dans un studio, même avec un petit budget ?** Le sur-mesure a un coût plus élevé qu'un meuble standard à l'achat, mais il permet d'exploiter des volumes qu'aucun meuble du commerce ne peut occuper efficacement. Sur un studio, où chaque centimètre compte, cet investissement se traduit souvent par un gain de fonctionnalité difficile à obtenir autrement.",
          "**Comment séparer les espaces dans un studio sans cloisonner ?** Plusieurs solutions existent sans construire de cloison : un changement de matériau au sol, une différence de niveau, un meuble bas faisant office de séparation visuelle, ou un jeu d'éclairage différencié par zone. Ces techniques permettent de distinguer les usages tout en conservant la sensation d'un espace ouvert et lumineux.",
          "**Un studio de 30 m² peut-il accueillir un vrai coin bureau ?** Oui, à condition de l'intégrer dès la conception du plan plutôt que de l'ajouter après coup. Un bureau intégré à un agencement sur mesure — par exemple prolongeant un meuble de rangement ou glissé sous une mezzanine — occupe beaucoup moins d'espace qu'un bureau autonome tout en restant pleinement fonctionnel.",
        ],
      },
    ],
    keywords: [
      "Aménagement studio Paris",
      "Optimiser petit espace",
      "Agencement sur mesure studio",
    ],
    relatedProjects: ["casa-duy"],
  },
  {
    slug: "transformer-2-pieces-en-3-pieces-paris",
    title:
      "Transformation d'un 2 pièces en 3 pièces à Paris : repenser l'espace sans perdre en confort",
    metaTitle: "Transformer un 2 Pièces en 3 Pièces à Paris",
    excerpt:
      "Diviser le séjour, repenser le plan, déplacer la cuisine : comment transformer un 2 pièces parisien en 3 pièces sans assombrir l'appartement ni perdre en confort.",
    date: "2026-08-26",
    category: "Rénovation & Architecture d'Intérieur",
    cover: "/assets/images/transformation-2-pieces-3-pieces-paris-cuisine-verte.jpg",
    readingTime: "8 min",
    intro:
      "À Paris, chaque mètre carré compte. Lorsque les besoins évoluent, un appartement de deux pièces peut rapidement devenir trop petit : arrivée d'un enfant, création d'un espace de télétravail, besoin d'une chambre supplémentaire ou simplement envie de mieux répartir les fonctions du logement. Transformer un 2 pièces en 3 pièces à Paris est pourtant rarement une simple question de cloisonnement : dans un appartement compact, créer une pièce supplémentaire sans assombrir le séjour, réduire les circulations ou donner une impression d'exiguïté demande une véritable réflexion d'architecture intérieure. L'enjeu est de gagner une pièce sans perdre la qualité de l'espace.",
    sections: [
      {
        heading: "Transformer un 2 pièces en 3 pièces : une question d'usage avant tout",
        paragraphs: [
          "Un appartement de deux pièces est généralement composé d'un séjour, d'une chambre, d'une cuisine et d'une salle de bains. Pour créer un trois pièces, la première idée consiste souvent à diviser le séjour afin d'obtenir une seconde chambre. Cette solution peut fonctionner, mais elle n'est pas toujours la meilleure. À Paris, les appartements présentent souvent des plans anciens, des murs porteurs, des fenêtres peu nombreuses, des pièces traversantes ou au contraire très cloisonnées. La transformation doit donc partir de l'existant.",
          "Avant de déplacer une cloison, il faut comprendre comment le logement est réellement utilisé : où se trouve la lumière naturelle, quelles pièces bénéficient des fenêtres, peut-on déplacer la cuisine, les cloisons existantes sont-elles porteuses, où sont les réseaux d'eau et d'évacuation, quelle surface peut réellement être consacrée à une nouvelle chambre, comment conserver une pièce de vie agréable, et faut-il privilégier une chambre classique, une chambre d'enfant ou un bureau pouvant évoluer. Une bonne transformation ne consiste pas à ajouter artificiellement une pièce : elle consiste à recomposer l'appartement autour de nouveaux usages.",
        ],
      },
      {
        heading: "Diviser le séjour",
        paragraphs: [
          "C'est la solution la plus évidente lorsque le salon dispose d'une surface importante. Une partie du séjour peut être transformée en chambre en créant une nouvelle cloison. Pour conserver un espace de vie agréable, le dessin de cette séparation est essentiel.",
          "Une cloison pleine peut rapidement rendre le séjour sombre. Selon la configuration, on peut alors travailler avec une verrière, une cloison vitrée, une imposte, une porte vitrée ou une séparation partiellement ouverte. L'objectif est de créer une véritable pièce tout en conservant la circulation de la lumière.",
        ],
        image: {
          src: "/assets/images/verriere-cloison-vitree-bureau-appartement-paris.jpg",
          caption: "Verrière séparant un bureau du séjour, appartement parisien, Supra Studio",
        },
      },
      {
        heading: "Repenser complètement le plan",
        paragraphs: [
          "Dans certains appartements, la meilleure solution consiste à revoir l'organisation générale plutôt qu'à simplement diviser une pièce. Déplacer la cuisine, réduire une circulation inutile ou redistribuer l'entrée peut permettre de récupérer plusieurs mètres carrés utiles. Un couloir trop large, une cuisine mal positionnée ou une succession de petites pièces peuvent parfois représenter un potentiel important — c'est particulièrement intéressant dans les appartements parisiens anciens, où le plan existant ne correspond plus nécessairement aux modes de vie contemporains.",
        ],
      },
      {
        heading: "Transformer une cuisine séparée",
        paragraphs: [
          "Lorsque la cuisine possède une surface relativement importante, elle peut parfois être déplacée ou intégrée au séjour. Cette stratégie permet de libérer une pièce supplémentaire pour créer une chambre. La création d'une cuisine ouverte peut également agrandir visuellement la pièce de vie, mais elle doit être étudiée avec soin : position des réseaux, ventilation, évacuations, rangements et intégration esthétique doivent être anticipés dès la conception.",
        ],
      },
      {
        heading: "Créer une petite chambre plutôt qu'une grande pièce multifonctionnelle",
        paragraphs: [
          "À Paris, quelques mètres carrés supplémentaires peuvent faire une grande différence. Une chambre de petite dimension peut parfaitement fonctionner si son plan est pensé sur mesure : lit intégré, rangements toute hauteur, portes coulissantes, mobilier réalisé sur mesure et circulation réduite au minimum. Dans un appartement compact, la qualité du plan compte souvent davantage que la taille brute de chaque pièce.",
        ],
      },
      {
        heading: "Peut-on transformer un 2 pièces de 40 m² en 3 pièces ?",
        paragraphs: [
          "Oui, mais la faisabilité dépend entièrement du plan existant. Un appartement de 40 m² peut, dans certaines configurations, devenir un véritable trois pièces. Dans d'autres, créer une troisième pièce conduirait à des espaces trop petits ou insuffisamment éclairés. La question n'est donc pas uniquement celle de la surface : un appartement de 40 m² bien distribué peut être beaucoup plus confortable qu'un appartement de 45 m² mal organisé.",
          "Pour chaque projet, il faut notamment étudier la position et la dimension des fenêtres, la hauteur sous plafond, les murs porteurs, les gaines techniques, les arrivées et évacuations d'eau, les possibilités de déplacement de la cuisine, les contraintes de copropriété, les besoins de ventilation, ainsi que la surface et la configuration des futures chambres. Une étude de faisabilité permet de vérifier ces éléments avant de s'engager dans les travaux.",
        ],
      },
      {
        heading: "Créer une chambre supplémentaire sans assombrir l'appartement",
        paragraphs: [
          "C'est probablement l'un des principaux défis d'une transformation de 2 pièces en 3 pièces. La lumière naturelle est particulièrement précieuse dans un petit appartement : une cloison supplémentaire peut rapidement transformer un logement lumineux en succession de pièces sombres. L'architecture intérieure permet alors de travailler sur plusieurs niveaux — les séparations peuvent être vitrées ou semi-transparentes, les portes peuvent être coulissantes, les circulations peuvent être réduites, et les perspectives visuelles peuvent être conservées depuis l'entrée jusqu'au séjour.",
          "Les matériaux jouent également un rôle important : couleurs claires, menuiseries sur mesure, miroirs intégrés avec parcimonie, bois, textiles et éclairage architectural permettent de créer des espaces chaleureux sans les alourdir. L'objectif n'est pas de faire paraître artificiellement l'appartement plus grand, mais de faire circuler la lumière et les regards de manière cohérente.",
        ],
      },
      {
        heading: "L'architecture sur mesure pour gagner de la place",
        paragraphs: [
          "Dans un appartement parisien, le mobilier fait partie intégrante du projet architectural. Lorsqu'un 2 pièces devient un 3 pièces, chaque centimètre peut être optimisé : une bibliothèque peut intégrer une porte, un meuble peut séparer deux fonctions, une tête de lit peut devenir un rangement, une banquette peut intégrer des coffres, une cuisine peut être dessinée jusqu'au plafond.",
          "Le sur-mesure permet surtout d'éviter d'accumuler du mobilier indépendant dans des pièces déjà petites. Cette approche donne également une cohérence esthétique à l'ensemble du logement : moins de meubles, mais mieux intégrés.",
        ],
      },
      {
        heading: "Transformer un 2 pièces en 3 pièces à Paris : quelles autorisations ?",
        paragraphs: [
          "Avant de commencer les travaux, il est important d'identifier les contraintes techniques et administratives du projet. La modification de cloisons intérieures peut être relativement simple lorsqu'elle ne touche pas à la structure de l'immeuble. En revanche, les interventions sur un mur porteur, les réseaux collectifs, les façades ou certaines parties communes peuvent nécessiter des autorisations spécifiques.",
          "Dans une copropriété parisienne, le règlement de copropriété doit également être consulté. Selon la nature des travaux, il peut être nécessaire de solliciter l'accord de la copropriété, de la mairie ou de faire intervenir un bureau d'études. C'est pourquoi une transformation réussie commence toujours par une analyse précise de l'existant et des contraintes du bâtiment.",
        ],
      },
      {
        heading: "Une transformation cohérente avec l'histoire de l'appartement",
        paragraphs: [
          "Transformer un appartement parisien ne signifie pas nécessairement effacer son caractère existant. Au contraire, la transformation peut être l'occasion de révéler certains éléments : parquet ancien, moulures, hauteur sous plafond, portes, cheminées, matériaux ou proportions caractéristiques de l'appartement. L'architecture intérieure contemporaine peut dialoguer avec ces éléments plutôt que de les remplacer systématiquement. Créer une chambre supplémentaire devient alors un projet global : améliorer le plan, les usages et le confort tout en conservant l'identité du lieu.",
        ],
      },
      {
        heading: "Un 2 pièces peut devenir un 3 pièces sans perdre son âme",
        paragraphs: [
          "La transformation d'un 2 pièces en 3 pièces à Paris est avant tout un exercice d'équilibre. Il faut trouver la bonne répartition entre chambre, séjour, cuisine, rangements et circulations, optimiser les mètres carrés sans donner l'impression d'un appartement surchargé, et créer une nouvelle pièce tout en conservant lumière, perspectives et confort. Chaque appartement possède ses propres contraintes et son propre potentiel : il n'existe donc pas de plan type pour passer de deux à trois pièces.",
          "Chez Supra Studio, nous abordons ce type de projet comme une véritable démarche d'architecture intérieure : analyse de l'existant, étude de faisabilité, recherche de plusieurs scénarios d'aménagement, conception du plan et travail sur les matériaux, la lumière et le mobilier sur mesure. L'objectif est simple : faire mieux avec l'espace existant, plutôt que simplement faire entrer davantage de pièces.",
          "**Votre appartement parisien ne correspond plus à votre mode de vie ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une visite-conseil, ou [contactez-nous](/contact) pour en discuter.",
        ],
      },
      {
        heading: "Questions fréquentes",
        paragraphs: [
          "**Quel budget prévoir pour transformer un 2 pièces en 3 pièces à Paris ?** Le budget dépend de l'ampleur des travaux (simple cloisonnement ou redistribution complète du plan, déplacement de cuisine). Pour des fourchettes de prix détaillées selon le type d'intervention, consultez notre article sur le [prix d'un architecte d'intérieur à Paris](/journal/prix-architecte-interieur-paris-m2-2026).",
          "**Faut-il l'accord de la copropriété pour ce type de projet ?** Cela dépend de la nature des travaux : la modification d'une cloison non porteuse ne nécessite généralement pas d'autorisation de copropriété, mais toute intervention touchant un mur porteur, une façade ou des parties communes doit être soumise au syndic, voire à la mairie selon les cas.",
          "**Combien de temps prennent des travaux de transformation d'un 2 pièces en 3 pièces ?** La durée varie selon l'ampleur du projet : un simple cloisonnement peut se réaliser en quelques semaines, tandis qu'une redistribution complète du plan avec déplacement de cuisine et reprise des réseaux demande généralement plusieurs mois, conception comprise.",
          "**Peut-on transformer un 2 pièces en 3 pièces sans toucher à un mur porteur ?** Oui, c'est même la configuration la plus simple et la plus rapide à mettre en œuvre. C'est notamment le cas lorsque le séjour est suffisamment grand pour être divisé par une cloison non porteuse, ou lorsque l'appartement comporte des circulations ou des pièces annexes qui peuvent être réorganisées sans intervention structurelle.",
        ],
      },
    ],
    keywords: [
      "2 pièces en 3 pièces Paris",
      "Transformation appartement Paris",
      "Rénovation appartement Paris",
    ],
    relatedProjects: ["casa-duy", "maison-kleber"],
  },
  {
    slug: "cuisine-ouverte-paris-amenagement-optimal",
    title: "Cuisine ouverte à Paris : comment réussir l'aménagement optimal ?",
    metaTitle: "Cuisine Ouverte Paris : Aménagement Optimal",
    excerpt:
      "Triangle d'activité, îlot ou péninsule, gestion des odeurs et du bruit : comment penser l'aménagement d'une cuisine ouverte parisienne pour qu'elle reste confortable au quotidien.",
    date: "2026-08-31",
    category: "Architecture d'Intérieur & Agencement",
    cover: "/assets/images/cuisine-ouverte-ilot-central-paris-vue-tour-eiffel.jpg",
    readingTime: "7 min",
    intro:
      "Ouvrir sa cuisine sur le séjour est devenu, à Paris, l'un des projets de rénovation les plus demandés. Plus de lumière, une pièce de vie qui semble plus grande, une convivialité retrouvée entre la préparation d'un repas et la vie du foyer : les bénéfices sont réels. Mais abattre une cloison ne suffit jamais à faire une bonne cuisine ouverte. Une cuisine ouverte mal pensée peut au contraire devenir une source de gêne quotidienne : odeurs qui envahissent le séjour, bruit de la hotte pendant une conversation, désordre visible depuis le canapé, circulation entravée entre deux personnes qui cuisinent. L'aménagement optimal d'une cuisine ouverte n'est donc pas une question d'esthétique seule : c'est un exercice d'architecture intérieure à part entière, qui doit anticiper les usages avant de choisir les matériaux.",
    sections: [
      {
        heading: "Penser l'aménagement avant l'ouverture elle-même",
        paragraphs: [
          "La première erreur consiste à considérer l'ouverture d'une cuisine comme une simple suppression de mur. Avant toute démolition, il faut se poser les bonnes questions : comment le foyer cuisine-t-il réellement ? Combien de personnes s'activent en même temps dans la cuisine ? La pièce doit-elle pouvoir se refermer visuellement lors d'une réception ? Quelle place occupe la table à manger dans l'équation ?",
          "Ces questions déterminent l'implantation de la cuisine bien avant le choix des matériaux ou des couleurs. Un couple qui cuisine rarement à deux n'a pas les mêmes besoins de circulation qu'une famille où plusieurs personnes s'activent simultanément autour du plan de travail. Un studio ou un deux-pièces parisien n'autorise pas les mêmes volumes qu'un appartement familial de 90 m². L'aménagement optimal part toujours de ces usages réels, jamais d'un plan type reproduit d'un projet à l'autre.",
        ],
      },
      {
        heading: "Organiser la circulation autour du triangle d'activité",
        paragraphs: [
          "En cuisine, trois zones concentrent l'essentiel de l'activité : la cuisson, le lavage et le rangement (réfrigérateur et garde-manger). La disposition de ces trois pôles — ce que les architectes d'intérieur appellent le triangle d'activité — conditionne directement le confort d'usage au quotidien.",
          "Dans une cuisine ouverte, ce triangle doit rester compact et sans obstacle, tout en laissant une circulation fluide vers le séjour. Un plan de travail trop long oblige à des déplacements inutiles ; un triangle trop resserré peut au contraire créer des croisements gênants lorsque plusieurs personnes cuisinent ensemble. L'équilibre juste dépend de la surface disponible, de la forme de la pièce et du nombre d'utilisateurs réguliers de la cuisine. C'est également à ce stade que se décide l'implantation de l'îlot ou de la péninsule, souvent le point central de l'aménagement.",
        ],
        image: {
          src: "/assets/images/ilot-cuisine-ouverte-convivialite-appartement-parisien.jpg",
          caption: "Îlot central et circulation fluide vers le séjour, appartement parisien, Supra Studio",
        },
      },
      {
        heading: "Îlot ou péninsule : quelle solution selon la surface ?",
        paragraphs: [
          "L'îlot central s'est imposé comme le symbole de la cuisine ouverte contemporaine : il structure l'espace, offre un plan de travail supplémentaire et devient naturellement un lieu de vie où l'on peut prendre un café en discutant. Mais l'îlot exige un dégagement suffisant sur son pourtour — au moins 90 cm à 100 cm de circulation de chaque côté — pour rester confortable à l'usage. Dans une cuisine trop restreinte, un îlot mal dimensionné devient un obstacle plutôt qu'un atout.",
          "Dans les appartements parisiens de taille plus modeste, la péninsule — un plan de travail prolongé et adossé sur un côté — offre souvent une alternative plus pertinente : elle conserve les avantages fonctionnels et sociaux de l'îlot tout en libérant davantage d'espace de circulation. Le choix entre les deux solutions doit se faire à partir des dimensions réelles de la pièce, et non par simple préférence esthétique.",
        ],
      },
      {
        heading: "Maîtriser les odeurs et le bruit : l'enjeu invisible d'une cuisine ouverte",
        paragraphs: [
          "C'est souvent l'aspect le moins anticipé, et pourtant le plus déterminant pour le confort au quotidien. Une cuisine ouverte sur le séjour expose immédiatement toute la pièce de vie aux odeurs de cuisson et au bruit des appareils. Une hotte sous-dimensionnée ou mal positionnée, ou une table de cuisson sans extraction efficace, peuvent rapidement rendre la cuisine ouverte inconfortable, en particulier avec une cuisson à forte odeur.",
          "Plusieurs solutions permettent d'anticiper ce problème dès la conception : une hotte à forte capacité d'extraction correctement dimensionnée pour le volume de la pièce, un système d'aspiration intégré à la table de cuisson pour réduire les nuisances sonores et visuelles, ou encore une ventilation mécanique renforcée. Le choix dépend aussi des contraintes techniques de l'immeuble — en copropriété parisienne, l'évacuation vers l'extérieur ou vers une gaine collective existante doit être vérifiée avant tout engagement, ce qui suppose une bonne connaissance des règles de copropriété et des réseaux existants.",
        ],
      },
      {
        heading: "Des rangements pensés pour disparaître",
        paragraphs: [
          "Une cuisine ouverte fonctionne d'autant mieux qu'elle sait se faire discrète en dehors des moments de préparation. L'agencement sur mesure permet d'intégrer l'électroménager derrière des façades continues avec le reste du mobilier, de multiplier les rangements en hauteur pour libérer le plan de travail, et de dissimuler la vaisselle du quotidien dans des tiroirs profonds plutôt que sur des étagères ouvertes.",
          "Cette recherche de continuité visuelle avec le reste de la pièce de vie est ce qui distingue une cuisine ouverte réussie d'une simple cuisine sans porte. Le choix des matériaux — une même teinte de façade que les rangements du séjour, un plan de travail qui prolonge une console ou un meuble bas — renforce cette impression d'unité, plutôt que de juxtaposer deux univers distincts dans la même pièce.",
        ],
      },
      {
        heading: "Lumière et continuité avec le séjour",
        paragraphs: [
          "Une cuisine ouverte bien aménagée ne se distingue pas du séjour par une rupture de style, mais par une continuité maîtrisée. Un éclairage zoné — suspensions basses au-dessus de l'îlot, éclairage indirect intégré aux façades, spots dédiés au plan de travail — permet de distinguer les usages sans cloisonner visuellement l'espace. Le choix d'un revêtement de sol continu entre la cuisine et le séjour participe également à cette impression d'unité, essentielle dans les appartements parisiens où chaque mètre carré doit sembler généreux.",
        ],
      },
      {
        heading: "Les contraintes techniques à anticiper à Paris",
        paragraphs: [
          "Dans l'ancien parisien, ouvrir une cuisine implique presque toujours de composer avec des contraintes techniques : présence d'un mur porteur nécessitant une étude structurelle, déplacement des arrivées d'eau et d'évacuation, mise aux normes du réseau électrique pour l'électroménager, ou encore vérification des possibilités de ventilation en copropriété. Ces éléments doivent être étudiés dès la phase de faisabilité, avant même de dessiner le plan définitif de la cuisine, pour éviter des surprises coûteuses en cours de chantier.",
        ],
      },
      {
        heading: "Comment nous abordons un projet de cuisine ouverte chez Supra Studio",
        paragraphs: [
          "Chez Supra Studio, l'aménagement d'une cuisine ouverte commence toujours par une lecture précise des usages du foyer et des contraintes techniques du logement, avant toute question de matériaux ou de style. Nous étudions la circulation, le dimensionnement de l'îlot ou de la péninsule, les solutions de ventilation adaptées, et l'agencement sur mesure des rangements, pour une cuisine qui reste confortable au quotidien autant qu'élégante lors d'une réception.",
          "**Vous envisagez d'ouvrir votre cuisine sur votre séjour ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une visite-conseil, ou [contactez-nous](/contact) pour en discuter.",
        ],
      },
      {
        heading: "Questions fréquentes",
        paragraphs: [
          "**Quelle surface minimale pour ouvrir une cuisine avec îlot central ?** Un îlot central confortable nécessite généralement une pièce d'au moins 15 à 20 m², afin de conserver une circulation d'au moins 90 cm à 100 cm sur son pourtour. En dessous de cette surface, une péninsule ou un plan en L le long d'un mur reste souvent plus adapté.",
          "**Comment éviter que les odeurs de cuisine envahissent le séjour ?** Une hotte correctement dimensionnée pour le volume de la pièce, associée à une bonne ventilation mécanique et, si besoin, un système d'aspiration intégré à la table de cuisson, permettent de limiter significativement la propagation des odeurs vers le séjour.",
          "**Faut-il privilégier des matériaux différents entre la cuisine et le séjour ?** Non : la continuité des matériaux (sol, teintes de façade, plans de travail en prolongement du mobilier) est justement ce qui distingue une cuisine ouverte réussie d'une simple pièce sans cloison. Pour des exemples de matières et de finitions haut de gamme, notre article sur la [cuisine ouverte sur-mesure en pièce de vie haut de gamme](/journal/cuisine-ouverte-haut-de-gamme-agencement-sur-mesure) détaille cette approche.",
          "**Quel budget prévoir pour l'ouverture et l'aménagement d'une cuisine à Paris ?** Le budget dépend fortement de la présence ou non d'un mur porteur, du déplacement des réseaux et du niveau d'agencement sur mesure souhaité. Pour des fourchettes de prix détaillées, consultez notre article sur le [prix d'un architecte d'intérieur à Paris](/journal/prix-architecte-interieur-paris-m2-2026).",
        ],
      },
    ],
    keywords: [
      "Cuisine ouverte Paris",
      "Aménagement cuisine ouverte",
      "Îlot central cuisine",
    ],
    relatedProjects: ["casa-duy", "maison-kleber"],
  },
  {
    slug: "amenagement-duplex-paris-exploiter-hauteur",
    title: "Aménagement d'un duplex à Paris : comment exploiter pleinement la hauteur ?",
    metaTitle: "Aménagement Duplex Paris : Exploiter la Hauteur",
    excerpt:
      "Escalier, double hauteur, niveau sous combles : comment penser l'aménagement d'un duplex parisien pour que la hauteur devienne un atout architectural plutôt qu'un volume perdu.",
    date: "2026-09-07",
    category: "Vision & Architecture d'Intérieur",
    cover: "/assets/images/duplex-parisien-double-hauteur-charpente-bois-verriere.jpg",
    readingTime: "8 min",
    intro:
      "Un duplex parisien est un privilège rare : la hauteur, l'escalier intérieur, parfois une double hauteur sous verrière ou sous charpente — autant d'éléments qui distinguent immédiatement ce type de bien de l'appartement standard. Mais cette hauteur, si elle n'est pas pensée avec rigueur, se transforme vite en volume perdu : un plafond haut ne fait pas à lui seul un appartement réussi. L'enjeu d'un aménagement de duplex n'est donc pas de constater la hauteur disponible, mais de la faire vivre — par la lumière, la circulation, les proportions et le choix des matériaux. Chez Supra Studio, nous abordons chaque duplex comme un projet à part entière, où l'escalier, le niveau sous combles et la double hauteur deviennent des éléments de composition architecturale, et non de simples contraintes à gérer.",
    sections: [
      {
        heading: "Le duplex parisien : un potentiel architectural souvent sous-exploité",
        paragraphs: [
          "À Paris, les duplex prennent des formes très variées : dernier étage d'un immeuble haussmannien avec combles aménagés, ancien atelier d'artiste à verrière, loft industriel reconverti, ou appartement neuf conçu dès l'origine sur deux niveaux. Chacune de ces configurations impose ses propres contraintes — hauteur sous charpente variable, pentes de toiture, poutres apparentes, verrière à préserver — mais partage un même potentiel : celui d'offrir des volumes que l'on ne retrouve dans aucun appartement de plain-pied.",
          "Trop souvent, ce potentiel reste sous-exploité : un escalier disgracieux planté au milieu d'une pièce, un niveau supérieur réduit à une simple chambre sous les toits, une double hauteur qui n'apporte rien de plus qu'un volume vide au-dessus du canapé. Un aménagement réussi part au contraire d'une question simple : qu'est-ce que cette hauteur permet de faire, que l'appartement ne pourrait pas faire autrement ?",
        ],
      },
      {
        heading: "L'escalier, pièce maîtresse de la composition",
        paragraphs: [
          "Dans un duplex, l'escalier n'est jamais un simple élément de circulation : c'est souvent la pièce la plus visible de l'appartement, celle qui structure le regard depuis l'entrée jusqu'au niveau supérieur. Son positionnement mérite donc une réflexion à part entière, au même titre que l'implantation d'une cuisine ou d'une salle de bains.",
          "Un escalier peut être traité comme un objet sculptural — ossature métallique fine, marches suspendues, garde-corps en verre pour ne pas obstruer la lumière — ou au contraire s'intégrer discrètement dans un caisson en bois qui dialogue avec le reste du mobilier. Le choix dépend de l'ambiance recherchée, mais aussi d'une contrainte très concrète : un escalier mal positionné peut condamner un mur entier ou fragmenter inutilement une pièce du rez-de-chaussée. Nous étudions systématiquement plusieurs implantations avant de figer un plan, pour que l'escalier serve la composition plutôt que de la subir.",
          "L'espace sous l'escalier, souvent négligé, représente également un gisement de rangement précieux dans un duplex parisien où chaque mètre carré compte : placards sur mesure, bibliothèque intégrée, ou même un bureau glissé dans la hauteur disponible.",
        ],
        image: {
          src: "/assets/images/escalier-duplex-mezzanine-bibliotheque-appartement-paris.jpg",
          caption: "Escalier et mezzanine bibliothèque sous charpente, duplex parisien, Supra Studio",
        },
      },
      {
        heading: "Exploiter la double hauteur sans la sacrifier",
        paragraphs: [
          "La double hauteur est l'atout le plus spectaculaire d'un duplex — et le plus délicat à doser. Conserver un vide sur toute la hauteur du séjour crée un effet architectural fort, baigne la pièce de lumière verticale et donne une sensation d'ampleur rare dans Paris. Mais un vide mal dimensionné peut aussi devenir un volume froid, difficile à chauffer et à meubler, qui prive l'étage d'une surface au sol dont l'appartement aurait pourtant besoin.",
          "La question n'est donc pas de choisir entre double hauteur et surface utile, mais de doser précisément où l'une justifie de renoncer à l'autre. Conserver le vide au-dessus du séjour tout en fermant partiellement l'étage au-dessus de la cuisine ou d'une salle d'eau permet souvent de profiter du meilleur des deux options : un geste architectural fort là où il a le plus d'impact visuel, et une surface généreuse là où le quotidien en a le plus besoin.",
        ],
      },
      {
        heading: "Aménager le niveau sous combles",
        paragraphs: [
          "Le niveau supérieur d'un duplex parisien se glisse souvent sous une toiture en pente, ce qui impose de penser le mobilier différemment d'un plafond droit. La règle est simple : placer les usages qui demandent le plus de hauteur — passage, dressing, tête de lit — au point le plus haut, et réserver les zones sous pente aux rangements bas, aux assises ou au rangement pur, où une hauteur réduite ne pose aucune gêne.",
          "Le mobilier sur mesure prend ici tout son sens : un lit dessiné pour s'encastrer précisément sous une pente, des rangements dont la façade suit l'inclinaison du toit plutôt que de créer des recoins morts, une tête de lit qui habille la partie la plus basse de la pièce. Les fenêtres de toit jouent également un rôle déterminant : bien positionnées, elles apportent une lumière zénithale qui manque souvent aux étages sous combles, et peuvent transformer une pièce autrement sombre en espace parmi les plus lumineux de l'appartement.",
        ],
      },
      {
        heading: "Créer une continuité entre les deux niveaux",
        paragraphs: [
          "Un duplex réussi ne se limite pas à deux appartements superposés reliés par un escalier : il fonctionne comme un seul espace de vie continu, où le regard circule librement d'un niveau à l'autre. Un garde-corps en verre plutôt qu'une rambarde pleine, une trémie d'escalier qui laisse deviner l'étage depuis le séjour, des matériaux de sol ou des teintes murales qui se répondent entre les deux niveaux : ces choix renforcent la sensation d'unité architecturale, plutôt que de traiter chaque étage comme un lot indépendant.",
          "Cette continuité se joue aussi dans la lumière : une fenêtre de toit au niveau supérieur peut éclairer indirectement le rez-de-chaussée à travers un vide central, si l'implantation de l'escalier et des cloisons le permet. Anticiper cette circulation de la lumière dès la conception évite d'avoir, une fois les travaux terminés, un rez-de-chaussée sombre sous un étage lumineux.",
        ],
      },
      {
        heading: "Bruit et intimité entre les niveaux",
        paragraphs: [
          "Un duplex pose une question rarement anticipée avant travaux : celle du bruit d'un niveau à l'autre. Sans isolation acoustique adaptée entre les planchers, les bruits de pas ou d'activité à l'étage se répercutent directement dans les pièces du dessous — un désagrément quotidien qui n'apparaît qu'une fois l'appartement habité.",
          "Le choix des fonctions par niveau mérite donc d'être pensé en amont : les chambres, qui demandent le plus de calme, se prêtent généralement mieux à un niveau haut légèrement à l'écart de la vie commune, tandis que les pièces de réception restent au rez-de-chaussée. Un traitement acoustique du plancher (chape flottante, sous-couche résiliente) reste également recommandé dès lors que le niveau supérieur accueille une chambre au-dessus d'une pièce de vie.",
        ],
      },
      {
        heading: "Les contraintes techniques propres à un duplex parisien",
        paragraphs: [
          "Aménager un duplex dans l'ancien parisien implique souvent de composer avec des contraintes spécifiques : charpente à préserver ou à renforcer selon les modifications envisagées, réglementation incendie applicable aux mezzanines et trémies au-delà d'une certaine surface, isolation thermique renforcée sous toiture, et selon les cas, autorisation de copropriété pour toute intervention touchant à la structure ou aux parties communes de la toiture. Ces éléments doivent être vérifiés dès la phase de faisabilité, avant même d'esquisser le plan définitif, pour sécuriser à la fois le budget et le calendrier du projet.",
        ],
      },
      {
        heading: "Comment nous abordons un projet de duplex chez Supra Studio",
        paragraphs: [
          "Un duplex se pense dans sa globalité, jamais niveau par niveau. Notre approche commence par une visite-conseil sur place pour évaluer la structure existante, la lumière naturelle à chaque niveau et les usages prioritaires du foyer. Nous étudions ensuite plusieurs scénarios d'implantation pour l'escalier, le dosage entre double hauteur et surface utile, et l'agencement sur mesure du niveau sous combles, avant de figer une conception qui met en valeur ce que seul un duplex peut offrir.",
          "**Vous envisagez d'aménager ou de rénover un duplex à Paris ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une visite-conseil, ou [contactez-nous](/contact) pour en discuter.",
        ],
      },
      {
        heading: "Questions fréquentes",
        paragraphs: [
          "**Quelle hauteur minimum pour créer une mezzanine dans un duplex ?** Une mezzanine confortable nécessite généralement au moins 2,50 m de hauteur au point le plus haut, pour conserver un dégagement suffisant à la fois en dessous et au-dessus. En dessous de ce seuil, un espace ouvert sans plancher supplémentaire reste souvent préférable.",
          "**Faut-il obligatoirement fermer la double hauteur pour gagner de la surface ?** Non. La bonne approche consiste généralement à doser : conserver le vide là où il a le plus d'impact architectural (au-dessus du séjour, par exemple), et fermer partiellement l'étage ailleurs pour gagner de la surface utile sans sacrifier l'effet de hauteur.",
          "**Quel budget prévoir pour l'aménagement d'un duplex à Paris ?** Le budget dépend fortement de l'ampleur des travaux : création ou déplacement d'un escalier, renforcement de charpente, isolation sous toiture. Pour des fourchettes de prix détaillées selon le type d'intervention, consultez notre article sur le [prix d'un architecte d'intérieur à Paris](/journal/prix-architecte-interieur-paris-m2-2026).",
          "**Comment limiter le bruit entre les deux niveaux d'un duplex ?** Un traitement acoustique du plancher (chape flottante, sous-couche résiliente sous le revêtement de sol) reste la solution la plus efficace, en particulier lorsque le niveau supérieur accueille une chambre. Le choix des fonctions par niveau — pièces calmes en hauteur, pièces de réception au rez-de-chaussée — limite également les nuisances au quotidien.",
        ],
      },
    ],
    keywords: [
      "Aménagement duplex Paris",
      "Duplex mezzanine Paris",
      "Double hauteur appartement",
    ],
    relatedProjects: ["casa-duy", "maison-kleber"],
  },
  {
    slug: "plu-bioclimatique-paris-paysagiste",
    title:
      "PLU bioclimatique à Paris : pourquoi faire appel à un paysagiste pour aménager votre extérieur ?",
    metaTitle: "PLU Bioclimatique Paris : Pourquoi Faire Appel à un Paysagiste",
    excerpt:
      "Pleine terre, végétalisation du bâti, arbres protégés : ce que change le PLU bioclimatique de Paris pour votre jardin, et pourquoi l'accompagnement d'un paysagiste devient essentiel.",
    date: "2026-09-15",
    category: "Design Paysager & Espaces Urbains",
    cover: "/assets/images/toiture-vegetalisee-paris-vue-tour-eiffel-sacre-coeur.jpg",
    readingTime: "7 min",
    intro:
      "Depuis novembre 2024, tout projet touchant à un espace extérieur à Paris — jardin, cour, toiture, façade — s'inscrit dans un cadre réglementaire renouvelé : le Plan Local d'Urbanisme bioclimatique, ou PLU bioclimatique. Premier document de ce type adopté en France, il redéfinit en profondeur la place du végétal dans la ville, avec des règles précises sur la pleine terre, la désimperméabilisation des sols et la végétalisation du bâti. Pour un particulier ou une entreprise qui envisage d'aménager un extérieur à Paris, ce nouveau cadre change la donne : un projet de jardin ou de terrasse ne se pense plus seulement en fonction de l'usage et de l'esthétique, mais aussi de ratios réglementaires précis, propres à chaque parcelle. C'est dans ce contexte que l'accompagnement d'un paysagiste devient un vrai atout — non plus seulement pour la conception, mais pour la conformité même du projet.",
    sections: [
      {
        heading: "Qu'est-ce que le PLU bioclimatique de Paris ?",
        paragraphs: [
          "Adopté par le Conseil de Paris le 20 novembre 2024, le PLU bioclimatique remplace l'ancien Plan Local d'Urbanisme qui datait de 2006. Il s'agit du premier PLU en France conçu explicitement autour des enjeux climatiques : adaptation au changement climatique, désimperméabilisation des sols, rénovation du bâti existant plutôt que démolition-reconstruction, et renforcement de la place du végétal dans l'espace urbain.",
          "Ce nouveau cadre ne se limite pas aux grands projets immobiliers : il s'applique à l'ensemble des projets d'aménagement soumis à autorisation d'urbanisme, y compris à l'échelle d'un jardin privé, d'une cour d'immeuble ou d'une toiture végétalisée.",
        ],
      },
      {
        heading: "Ce qui change pour un jardin ou une cour privée : la pleine terre",
        paragraphs: [
          "L'une des dispositions les plus concrètes du PLU bioclimatique concerne la notion de pleine terre : sur toute parcelle de plus de 150 m², jusqu'à 65 % de la surface doit rester en pleine terre, c'est-à-dire un sol non imperméabilisé, capable d'infiltrer l'eau de pluie et de permettre le développement racinaire des végétaux — par opposition à une dalle recouverte de terre en surface, comme sur une toiture ou un parking souterrain.",
          "Le PLU bioclimatique introduit également une nouvelle définition des espaces libres de construction (ELC), qui prend désormais en compte l'espace disponible en élévation comme en sous-sol. Un taux minimal d'ELC est imposé selon les zones, avec l'obligation de les réaliser en pleine terre ou de les végétaliser, et des exigences de densité de plantation qui augmentent avec la surface du projet. Concrètement, cela signifie que la conception d'un jardin ou d'une cour doit désormais intégrer ces ratios dès les premières esquisses, sous peine de devoir revoir le projet en cours de dépôt de permis.",
        ],
        image: {
          src: "/assets/images/cour-parisienne-vegetalisee-pleine-terre-jardin.jpg",
          caption: "Cour parisienne végétalisée en pleine terre, Supra Studio",
        },
      },
      {
        heading: "La végétalisation du bâti : toitures et façades",
        paragraphs: [
          "Au-delà du sol, le PLU bioclimatique instaure un indice de végétalisation du bâti, qui impose la réalisation de surfaces végétalisées en toiture ou en façade pour de nombreux projets. Cette exigence transforme la toiture ou la façade d'un bâtiment en un espace de conception paysagère à part entière, et non plus en simple surface technique.",
          "Dans les nombreux secteurs protégés de Paris, ces aménagements doivent composer avec un acteur supplémentaire : les Architectes des Bâtiments de France, systématiquement consultés dès lors qu'un projet touche à l'aspect extérieur d'un bâtiment en secteur protégé. Une toiture végétalisée ou une façade plantée doit donc être conçue en anticipant à la fois l'exigence climatique du PLU bioclimatique et les attentes patrimoniales de l'ABF — un exercice d'équilibre qui demande une vraie expertise technique et réglementaire.",
        ],
      },
      {
        heading: "Les espaces et arbres protégés à connaître",
        paragraphs: [
          "Le PLU bioclimatique renforce également la protection des éléments végétaux existants : espaces verts protégés, environ 100 000 arbres d'alignement, 266 arbres remarquables recensés sur le domaine public comme sur des parcelles privées, ainsi que des espaces libres protégés à végétaliser et des jardins partagés protégés.",
          "Pour un projet de paysage privé, cela signifie qu'il est essentiel de vérifier en amont si la parcelle concernée est soumise à l'une de ces protections, avant même d'esquisser un plan : un arbre remarquable présent sur le terrain, par exemple, encadre directement les possibilités d'implantation et de plantation. Cette vérification se fait via le Portail des règles d'urbanisme de Paris, qui recense les protections applicables parcelle par parcelle.",
        ],
      },
      {
        heading: "Pourquoi l'accompagnement d'un paysagiste devient indispensable",
        paragraphs: [
          "Face à cette densité réglementaire nouvelle, concevoir un jardin ou un espace extérieur à Paris ne relève plus seulement du choix esthétique. Calculer précisément le ratio de pleine terre exigé, vérifier les protections applicables à une parcelle, dialoguer avec l'administration et, le cas échéant, avec l'ABF, tout en conservant un espace réellement agréable à vivre : c'est un exercice qui demande une double compétence, technique et créative.",
          "Un paysagiste habitué à ce cadre réglementaire sait transformer ces contraintes en éléments de composition plutôt qu'en simples obstacles : une exigence de pleine terre peut devenir l'occasion de repenser intégralement l'implantation d'un jardin ; une obligation de végétalisation du bâti, l'opportunité de créer une toiture plantée qui prolonge visuellement l'intérieur du logement. C'est précisément l'articulation entre conformité réglementaire et qualité d'usage qui distingue un projet de paysage professionnel d'un aménagement mené sans accompagnement.",
        ],
      },
      {
        heading:
          "Comment nous abordons un projet de paysage soumis au PLU bioclimatique chez Supra Studio",
        paragraphs: [
          "Chez Supra Studio, chaque projet de paysage à Paris commence par une vérification des règles applicables à la parcelle concernée — pleine terre, espaces libres de construction, éventuelles protections patrimoniales ou végétales — avant même d'esquisser un plan. Cette étape technique, souvent sous-estimée, conditionne pourtant l'ensemble du projet : elle permet de concevoir un jardin ou un espace extérieur qui respecte le cadre réglementaire dès la conception, plutôt que de devoir le corriger a posteriori.",
          "**Vous envisagez un projet de jardin, de cour ou de toiture végétalisée à Paris ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une visite-conseil, ou [contactez-nous](/contact) pour en discuter.",
        ],
      },
      {
        heading: "Questions fréquentes",
        paragraphs: [
          "**Le PLU bioclimatique s'applique-t-il à toutes les parcelles parisiennes ?** L'obligation de pleine terre à hauteur de 65 % concerne les parcelles de plus de 150 m². Les parcelles plus petites restent néanmoins concernées par d'autres dispositions, notamment l'indice de végétalisation du bâti ou les protections spécifiques (arbres remarquables, espaces verts protégés) qui s'appliquent indépendamment de la taille du terrain.",
          "**Comment savoir si mon terrain est concerné par une protection du PLU bioclimatique ?** La vérification se fait via le Portail des règles d'urbanisme de Paris, qui recense parcelle par parcelle les espaces verts protégés, les arbres remarquables et les autres protections applicables. Cette étape est systématiquement intégrée à notre phase d'étude de faisabilité.",
          "**Le PLU bioclimatique s'applique-t-il aussi aux rénovations, ou seulement aux constructions neuves ?** Il s'applique largement aux deux : le PLU bioclimatique donne d'ailleurs la priorité à la rénovation du bâti existant plutôt qu'à la démolition-reconstruction, et les exigences de végétalisation du bâti concernent aussi les projets de rénovation énergétique d'immeubles existants.",
          "**Quel budget prévoir pour un projet de paysage conforme au PLU bioclimatique à Paris ?** Le budget dépend de la surface du projet, du niveau d'exigence en pleine terre ou en végétalisation, et de la présence éventuelle de protections spécifiques à intégrer dès la conception. Pour une approche générale des honoraires, consultez notre article sur le [prix d'un architecte d'intérieur à Paris](/journal/prix-architecte-interieur-paris-m2-2026).",
        ],
      },
    ],
    keywords: [
      "PLU bioclimatique Paris",
      "Paysagiste Paris",
      "Végétalisation Paris",
    ],
    relatedProjects: ["giardino-de-ninno"],
  },
  {
    slug: "honoraires-architecte-interieur-paris",
    title: "Honoraires d'un architecte d'intérieur à Paris : comment sont-ils calculés ?",
    metaTitle: "Honoraires Architecte d'Intérieur Paris : Comment Sont-ils Calculés ?",
    excerpt:
      "Pourcentage des travaux, forfait, taux horaire ou tarif au m² : comment se construit le montant des honoraires d'un architecte d'intérieur à Paris, et comment bien évaluer un devis.",
    date: "2026-09-21",
    category: "Conseils & expertise",
    cover: "/assets/images/architecte-interieur-paris-conception-plans-materiaux.jpg",
    readingTime: "7 min",
    intro:
      "Faire appel à un architecte d'intérieur à Paris soulève rapidement une question centrale : comment se construit le montant des honoraires ? Contrairement à une idée répandue, il n'existe pas de grille tarifaire unique ni de norme réglementaire fixant un prix standard. Chaque studio définit sa propre méthode de facturation, en fonction de la nature de la mission, de l'ampleur du projet et du niveau d'accompagnement proposé. Comprendre ces mécanismes permet d'aborder un projet de rénovation ou d'aménagement avec une vision budgétaire claire, et d'éviter les mauvaises surprises entre le premier rendez-vous et la livraison du chantier.",
    sections: [
      {
        heading: "Le pourcentage du montant des travaux",
        paragraphs: [
          "C'est le mode de facturation historique de la profession, encore majoritairement utilisé à Paris. L'architecte d'intérieur applique un taux, généralement compris entre 8 % et 15 %, calculé sur le montant total des travaux hors mobilier ou hors taxes selon les studios. Ce taux varie selon la complexité technique du chantier, la surface concernée et le niveau de finition visé.",
          "Ce mode de calcul présente une logique intéressante : il aligne l'intérêt de l'architecte sur celui du client. Un projet plus ambitieux, nécessitant davantage de coordination et de suivi, génère naturellement des honoraires proportionnellement plus élevés — sans pour autant inciter l'architecte à faire gonfler artificiellement le budget travaux, puisque sa réputation dépend avant tout de la qualité du résultat livré.",
        ],
      },
      {
        heading: "Le forfait",
        paragraphs: [
          "Pour des missions au périmètre bien délimité — conception d'un plan d'aménagement, définition d'une palette de matériaux, accompagnement sur une pièce spécifique — de nombreux studios proposent désormais un forfait fixe, établi en amont selon la surface et la nature exacte de la prestation.",
          "L'avantage principal de ce mode de facturation réside dans sa prévisibilité : le client connaît le montant exact dès la signature, indépendamment de l'évolution du budget travaux en cours de chantier. C'est une option particulièrement adaptée aux projets dont le périmètre est clairement identifiable dès le départ.",
        ],
      },
      {
        heading: "Le taux horaire et la facturation au mètre carré",
        paragraphs: [
          "Certaines missions ponctuelles ne justifient pas une facturation au pourcentage ou au forfait : un conseil sur un plan existant, une validation technique, un accompagnement limité dans le temps. Dans ces cas, la facturation à l'heure — généralement entre 80 € et 150 € à Paris selon l'expérience du professionnel — offre une flexibilité adaptée à des besoins circonscrits.",
          "Plus rare, la facturation au mètre carré s'applique surtout aux projets de grande envergure, où un tarif est fixé par mètre carré aménagé, généralement entre 100 € et 300 €/m² selon le niveau de prestation. Elle permet une estimation rapide dès les premières esquisses, avant même d'avoir un chiffrage détaillé des travaux.",
        ],
        image: {
          src: "/assets/images/moodboard-materiaux-architecte-interieur-salon-parisien.jpg",
          caption: "Sélection de matériaux et d'ambiances, salon parisien, Supra Studio",
        },
      },
      {
        heading: "Les facteurs qui font varier le montant des honoraires",
        paragraphs: [
          "Au-delà du mode de calcul choisi, plusieurs paramètres influencent directement le niveau des honoraires. La nature et la complexité du bien jouent un rôle déterminant : un appartement haussmannien avec moulures à préserver, un loft nécessitant une restructuration complète, ou un duplex avec création d'escalier n'impliquent pas le même niveau d'intervention technique.",
          "L'étendue de la mission confiée compte également : un simple conseil en aménagement n'a rien de comparable avec une mission complète intégrant conception, sélection des matériaux, coordination des artisans et suivi de chantier jusqu'à la livraison. Le niveau de prestation recherché influence aussi le montant — entre une rénovation fonctionnelle et un projet haut de gamme sur-mesure, l'écart de temps de conception, et donc d'honoraires, peut être significatif.",
          "Les contraintes spécifiques au bien parisien pèsent enfin dans la balance : copropriété avec règlement strict, immeuble classé ou situé en secteur protégé, accès complexe pour les artisans — autant d'éléments qui allongent le temps de gestion du projet. L'expérience et la notoriété du studio se reflètent également, comme dans toute profession créative, dans sa grille tarifaire.",
        ],
      },
      {
        heading: "Ce que couvrent généralement les honoraires",
        paragraphs: [
          "Une mission complète d'architecture d'intérieur inclut habituellement plusieurs volets, qu'il est essentiel de clarifier avant signature : la phase de conception avec les plans d'aménagement et les propositions d'esquisses, le choix des matériaux, finitions et mobilier avec constitution d'un book de prescription, la coordination des artisans et le pilotage du calendrier de chantier, les démarches administratives nécessaires — notamment auprès du syndic ou pour certaines autorisations d'urbanisme — et le suivi jusqu'à la livraison, incluant généralement un nombre défini de visites de chantier.",
          "Ce périmètre varie sensiblement d'un studio à l'autre : certains incluent un nombre illimité de retouches de plans, d'autres facturent chaque modification au-delà d'un seuil défini. C'est précisément ce qui justifie une lecture attentive du devis avant tout engagement.",
        ],
      },
      {
        heading: "Comment évaluer un devis d'architecte d'intérieur",
        paragraphs: [
          "Avant de s'engager, plusieurs vérifications permettent d'éviter les incompréhensions ultérieures. Il faut d'abord clarifier le périmètre exact de la mission — conception seule, ou conception associée à un suivi complet de chantier — puis demander le détail du mode de calcul des honoraires, et la base sur laquelle il s'applique (montant travaux HT ou TTC, mobilier inclus ou non).",
          "Il est également essentiel d'identifier ce qui est inclus dans le forfait ou le taux appliqué — nombre de visites de chantier, de réunions, de jeux de plans révisés — et de comparer plusieurs propositions à périmètre strictement équivalent, plutôt que sur le seul montant affiché.",
        ],
      },
      {
        heading: "Comment nous établissons nos honoraires chez Supra Studio",
        paragraphs: [
          "Chez Supra Studio, chaque devis est construit sur mesure, après une première visite du bien et un échange approfondi sur les attentes du projet. Nous détaillons systématiquement le périmètre exact de notre mission — conception, sélection des matériaux, coordination de chantier — ainsi que le mode de calcul retenu, afin que chaque client dispose d'une vision budgétaire claire dès le démarrage du projet.",
          "**Vous envisagez un projet de rénovation ou d'aménagement intérieur à Paris ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour un premier échange, ou [contactez-nous](/contact) pour obtenir un devis personnalisé.",
        ],
      },
      {
        heading: "Questions fréquentes",
        paragraphs: [
          "**Quel est le pourcentage moyen appliqué par un architecte d'intérieur à Paris ?** Le taux se situe généralement entre 8 % et 15 % du montant des travaux, selon la complexité du projet et le niveau de prestation. Ce taux doit systématiquement être précisé par écrit dans le devis, avec la base de calcul exacte (montant HT ou TTC, mobilier inclus ou non). Pour des fourchettes de budget détaillées selon le type de projet, consultez notre article sur le [prix d'un architecte d'intérieur à Paris](/journal/prix-architecte-interieur-paris-m2-2026).",
          "**Le devis d'un architecte d'intérieur est-il gratuit ?** Cela dépend de chaque studio : certains proposent un premier rendez-vous de découverte gratuit, d'autres facturent une prestation d'étude de faisabilité en amont, notamment pour les projets complexes nécessitant une visite technique approfondie. Il est recommandé de clarifier ce point dès le premier contact.",
          "**Peut-on négocier les honoraires d'un architecte d'intérieur ?** Le montant dépend avant tout du périmètre de la mission plutôt que d'une simple négociation tarifaire. Il est en revanche tout à fait possible d'ajuster le périmètre confié — par exemple en limitant la mission à la conception sans suivi de chantier — pour adapter le montant global au budget disponible.",
          "**Faut-il prévoir un budget supplémentaire en cours de projet ?** Selon le mode de facturation choisi, une évolution du montant des travaux en cours de chantier peut faire varier les honoraires calculés au pourcentage. C'est pourquoi il est essentiel de définir dès le départ un budget travaux réaliste, incluant une marge pour les imprévus, afin d'anticiper l'impact sur le montant final des honoraires. Pour connaître les fourchettes de prix des travaux eux-mêmes, poste par poste, consultez notre article sur le [coût d'une rénovation d'appartement à Paris](/journal/cout-renovation-appartement-paris-budget-complet).",
        ],
      },
    ],
    keywords: [
      "Honoraires architecte d'intérieur",
      "Devis architecte d'intérieur Paris",
      "Tarif architecte d'intérieur",
    ],
    relatedProjects: ["casa-duy", "maison-kleber"],
  },
  {
    slug: "cout-renovation-appartement-paris-budget-complet",
    title: "Coût rénovation appartement Paris : budget complet 2026",
    metaTitle: "Coût Rénovation Appartement Paris : Budget Complet des Travaux 2026",
    excerpt:
      "Rafraîchissement, rénovation complète ou rénovation lourde : découvrez le budget réel des travaux de rénovation d'un appartement à Paris en 2026, poste par poste.",
    date: "2026-09-28",
    category: "Conseils & expertise",
    cover: "/assets/images/budget-renovation-appartement-paris-2026-repartition-travaux.jpg",
    readingTime: "8 min",
    intro:
      "Combien coûte réellement la rénovation d'un appartement à Paris ? C'est la première question que se posent presque tous nos futurs clients, bien avant de penser aux matériaux ou au style. Et c'est une question légitime : entre un simple rafraîchissement et une rénovation lourde avec redistribution complète des volumes, l'écart de budget peut aller de un à dix. Cet article ne traite pas des honoraires d'architecte, mais exclusivement du **budget des travaux eux-mêmes** — gros œuvre, second œuvre, finitions, cuisine, salle de bains, électricité, plomberie — pour vous donner une vision réaliste et chiffrée du coût total d'un chantier à Paris en 2026.",
    sections: [
      {
        heading: "Les quatre niveaux de rénovation et leur coût au m²",
        paragraphs: [
          "Le coût d'une rénovation dépend avant tout de son ampleur. On distingue généralement quatre niveaux d'intervention, chacun avec sa propre fourchette de prix à Paris en 2026.",
          "**Le rafraîchissement** se limite aux finitions : peinture, revêtements de sol, remplacement de sanitaires ou de la cuisine sans toucher aux réseaux ni aux cloisons. C'est l'option la plus économique, comptez entre 300 € et 800 € par m². Elle convient à un appartement déjà fonctionnel, où seul l'aspect esthétique doit être repris.",
          "**La rénovation partielle** intervient dès que l'on touche à une partie de l'électricité, de la plomberie ou que l'on modifie quelques cloisons non porteuses. Cette catégorie couvre une fourchette large, de 600 € à 1 800 € par m², selon le nombre de postes concernés et l'état des réseaux existants.",
          "**La rénovation complète** reprend l'intégralité des réseaux (électricité aux normes, plomberie neuve), les revêtements de toutes les pièces et généralement la cuisine et la ou les salles de bains. C'est la configuration la plus fréquente pour un appartement ancien acquis dans l'optique d'y vivre durablement. Comptez entre 1 200 € et 2 000 € par m², voire jusqu'à 2 500 € par m² selon le niveau de finition retenu.",
          "**La rénovation lourde avec redistribution des volumes** implique la création ou la suppression de cloisons porteuses, une redistribution complète du plan, ou la transformation d'un logement à l'abandon depuis plusieurs décennies. Le budget grimpe alors entre 1 800 € et 3 000 € par m², et peut dépasser 3 500 € par m² dans l'ancien haussmannien nécessitant une reprise structurelle importante.",
          "À titre d'exemple concret, pour un appartement parisien de 50 m² : un rafraîchissement représente un budget de 20 000 € à 40 000 €, une rénovation complète se situe le plus souvent entre 60 000 € et 100 000 €, et une rénovation lourde avec redistribution peut atteindre 100 000 € à 160 000 €.",
        ],
        image: {
          src: "/assets/images/chantier-renovation-appartement-haussmannien-paris-parquet-plans.jpg",
          caption: "Chantier de rénovation dans un appartement haussmannien parisien, Supra Studio",
        },
      },
      {
        heading: "La majoration parisienne : pourquoi les travaux coûtent plus cher qu'en province",
        paragraphs: [
          "À surface et niveau de prestation identiques, les travaux à Paris coûtent en moyenne 15 % à 25 % plus cher qu'en région. Cette majoration s'explique par plusieurs contraintes propres à la capitale : difficulté d'accès aux immeubles anciens (absence d'ascenseur, cages d'escalier étroites rendant l'évacuation des gravats et la livraison des matériaux plus longues), stationnement limité pour les artisans, horaires de chantier restreints imposés par les règlements de copropriété, et une demande soutenue qui maintient les tarifs des entreprises du bâtiment à un niveau élevé. Ce surcoût doit être intégré dès l'établissement du budget prévisionnel, sous peine de mauvaise surprise au moment des premiers devis.",
        ],
      },
      {
        heading: "Le budget poste par poste : ce que coûte chaque corps de métier",
        paragraphs: [
          "Au-delà du prix global au m², il est utile de comprendre comment se répartit le budget entre les différents postes de travaux, pour identifier où se concentrent les principaux coûts d'un chantier.",
          "**La cuisine**, hors électroménager haut de gamme, représente un budget de 1 500 € à 2 500 € par m² de cuisine pour un agencement sur mesure de qualité. Pour une cuisine de 10 m², cela représente donc un investissement de 15 000 € à 25 000 €, auquel s'ajoute l'électroménager.",
          "**La salle de bains** est, avec la cuisine, la pièce la plus coûteuse au m² en raison de la densité des équipements techniques qu'elle concentre. Comptez entre 1 200 € et 2 500 € par m², soit un budget total de 4 500 € à 25 000 € selon la surface de la pièce et le niveau de gamme de la robinetterie, du carrelage et de la faïence choisis.",
          "**La plomberie** : la reprise complète des réseaux (alimentation et évacuation) représente un coût de 60 € à 110 € HT par m² habitable, un poste qui devient incontournable dès qu'un appartement ancien n'a pas été rénové depuis plusieurs décennies.",
          "**L'électricité** : la mise aux normes, obligatoire dans la plupart des rénovations lourdes, se chiffre entre 40 € et 130 € par m² selon l'état de l'installation existante et le nombre de points lumineux et de prises souhaités.",
          "**La peinture** standard sur murs et plafonds préparés coûte entre 25 € et 50 € HT par m², un tarif qui peut monter jusqu'à 80 € par m² pour des effets décoratifs (enduit à la chaux, béton ciré, papier peint haut de gamme).",
          "**Le déplacement de cloisons** : créer une cloison non porteuse coûte généralement entre 50 € et 90 € HT par m² de cloison, tandis que sa démolition revient à 30 € à 60 € HT par m². L'ouverture d'un mur porteur, qui nécessite la pose d'un IPN et une étude structurelle préalable, représente un budget spécifique de 3 500 € à 8 000 € selon la portée à franchir et la complexité de la reprise de charge.",
        ],
      },
      {
        heading: "Les facteurs qui font varier le budget d'un chantier",
        paragraphs: [
          "Deux appartements de surface identique peuvent afficher des budgets de travaux très différents. Plusieurs facteurs expliquent ces écarts.",
          "**L'état du bâti existant** est le premier critère : un appartement haussmannien avec parquet à reprendre, moulures à restaurer et plomberie en plomb à remplacer intégralement coûte nettement plus cher à traiter qu'un appartement des années 1990 en bon état général.",
          "**L'ampleur de la redistribution** pèse directement sur le budget : chaque mur déplacé implique une étude, une autorisation de copropriété si le mur est mitoyen ou porteur, la dépose, la reprise des sols et plafonds, et la remise en peinture des surfaces concernées.",
          "**Le règlement de copropriété** peut allonger la durée du chantier — horaires de travaux restreints, interdiction de certains gros œuvres les jours fériés — ce qui se répercute sur le coût de main-d'œuvre facturé par les entreprises.",
          "**Le niveau de finition** fait varier le budget du simple au double : le choix entre un carrelage d'entrée de gamme et une pierre naturelle, ou entre une peinture standard et un enduit à la chaux appliqué à la main, peut représenter plusieurs dizaines de milliers d'euros d'écart sur un projet de taille moyenne.",
        ],
      },
      {
        heading: "La TVA applicable aux travaux de rénovation",
        paragraphs: [
          "Le taux de TVA appliqué aux travaux dépend de leur nature et de l'ancienneté du logement. Le taux normal de 20 % s'applique aux logements de moins de deux ans ou aux travaux assimilés à une reconstruction. Le taux intermédiaire de 10 % couvre la grande majorité des travaux d'amélioration, de transformation et d'entretien réalisés dans un logement achevé depuis plus de deux ans — c'est le taux le plus fréquent pour une rénovation d'appartement parisien. Enfin, le taux réduit de 5,5 % s'applique spécifiquement aux travaux d'amélioration de la performance énergétique, à condition d'être réalisés par une entreprise certifiée RGE dans un logement de plus de deux ans.",
          "Ces taux réduits peuvent se cumuler avec des aides publiques telles que MaPrimeRénov', les Certificats d'Économie d'Énergie (CEE) ou l'Éco-PTZ, pour les projets intégrant une dimension de rénovation énergétique — un point à vérifier systématiquement en amont, car ces dispositifs peuvent alléger significativement le budget global.",
        ],
      },
      {
        heading: "Combien de temps dure un chantier, et pourquoi cela compte pour le budget",
        paragraphs: [
          "La durée du chantier a un impact direct sur le coût final, car chaque semaine supplémentaire représente des frais fixes (location d'engins, gardiennage de chantier, coordination). Un rafraîchissement simple se réalise en 2 à 4 semaines. Une rénovation complète avec reprise des réseaux demande généralement 2 à 4 mois. Une rénovation lourde avec modification du plan et démarches d'autorisation peut s'étendre sur 3 à 6 mois de travaux, auxquels s'ajoutent les délais de conception et d'instruction administrative en amont — portant la durée totale du projet, de la décision initiale à la livraison, à 4 à 6 mois en moyenne.",
        ],
      },
      {
        heading: "Comment nous établissons un budget de travaux chez Supra Studio",
        paragraphs: [
          "Chez Supra Studio, l'établissement d'un budget de travaux ne se limite jamais à l'application d'un prix au m² théorique. Notre première visite sur place nous permet d'évaluer précisément l'état du bâti, d'identifier les postes qui nécessiteront une reprise complète (réseaux, structure, isolation) et ceux qui pourront être conservés, puis de faire chiffrer chaque poste par les entreprises avec lesquelles nous travaillons régulièrement. Cette méthode permet d'obtenir un budget réaliste et détaillé, poste par poste, avant tout engagement de votre part.",
          "**Vous préparez un projet de rénovation à Paris ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour une visite-conseil, ou [contactez-nous](/contact) pour évaluer le budget de votre projet.",
        ],
      },
      {
        heading: "Questions fréquentes",
        paragraphs: [
          "**Quel budget prévoir pour rénover un appartement de 50 m² à Paris ?** Pour un rafraîchissement simple, comptez 20 000 € à 40 000 €. Pour une rénovation complète avec reprise des réseaux, le budget se situe généralement entre 60 000 € et 100 000 €. Pour une rénovation lourde avec redistribution des volumes, il faut prévoir entre 100 000 € et 160 000 €.",
          "**Quelle est la différence entre le budget des travaux et les honoraires d'architecte ?** Le budget des travaux couvre uniquement ce que facturent les artisans (gros œuvre, second œuvre, finitions). Les honoraires d'architecte d'intérieur, calculés séparément selon un forfait, un pourcentage des travaux ou un tarif horaire, rémunèrent la conception et le suivi de chantier. Le détail de ces modes de calcul est disponible dans notre article sur les [honoraires d'un architecte d'intérieur à Paris](/journal/honoraires-architecte-interieur-paris).",
          "**Pourquoi les travaux coûtent-ils plus cher à Paris qu'en province ?** Principalement en raison des contraintes d'accès aux immeubles anciens, du stationnement limité pour les artisans et des horaires de chantier souvent restreints par les règlements de copropriété. Cette majoration représente en moyenne 15 % à 25 % par rapport à un chantier équivalent en région.",
          "**Quels travaux bénéficient du taux de TVA réduit à 5,5 % ?** Seuls les travaux d'amélioration de la performance énergétique réalisés par une entreprise certifiée RGE, dans un logement achevé depuis plus de deux ans, bénéficient de ce taux réduit. La majorité des autres travaux de rénovation relèvent du taux intermédiaire de 10 %.",
          "**Faut-il prévoir une marge de sécurité dans le budget des travaux ?** Oui, il est recommandé de prévoir une marge de 10 % à 15 % du budget total pour absorber les imprévus fréquents dans l'ancien parisien : découverte d'un réseau électrique non conforme, d'une poutre à traiter, ou d'un aléa structurel révélé une fois les cloisons ouvertes.",
        ],
      },
    ],
    keywords: [
      "Coût rénovation appartement Paris",
      "Budget travaux rénovation Paris",
      "Prix rénovation appartement m2",
    ],
    relatedProjects: ["casa-duy", "maison-kleber"],
  },
  {
    slug: "choisir-architecte-interieur-paris",
    title: "Choisir son architecte d'intérieur à Paris : au-delà du style, une manière de penser",
    metaTitle: "Choisir son Architecte d'Intérieur à Paris : Guide et Critères de Sélection",
    excerpt:
      "Au-delà d'un book de réalisations, comment bien choisir son architecte d'intérieur à Paris ? Les vrais critères : écoute, raisonnement, capacité à transformer vos contraintes en atouts.",
    date: "2026-10-05",
    category: "Conseils & expertise",
    cover: "/assets/images/choisir-architecte-interieur-paris-visite-chantier-echange.jpg",
    readingTime: "7 min",
    intro:
      "La plupart des recherches commencent de la même façon : des heures passées à collectionner des images, des comptes à suivre, des intérieurs qui plaisent sans qu'on sache toujours pourquoi. C'est une étape naturelle, et même nécessaire. Mais elle entretient une confusion fréquente : choisir un architecte d'intérieur sur la base de ce qu'il a déjà produit, comme s'il s'agissait d'un catalogue dans lequel piocher un style. Chez Supra Studio, nous pensons que cette approche passe à côté de l'essentiel — et qu'elle expose à une déception fréquente, une fois le projet lancé : un intérieur esthétiquement réussi, mais qui ne ressemble pas à ses habitants.",
    sections: [
      {
        heading: "Ce qui se joue réellement derrière un projet d'intérieur",
        paragraphs: [
          "Un appartement n'est pas une addition de matériaux et de couleurs assemblés avec goût. C'est une réponse à une manière de vivre : la façon dont on reçoit, dont on travaille depuis chez soi, dont on circule le matin en étant pressé, dont on a besoin de silence le soir. Deux personnes qui partagent exactement les mêmes références esthétiques — les mêmes teintes, le même mobilier, les mêmes matières — peuvent avoir besoin de deux projets radicalement différents, simplement parce que leur rapport à l'espace, à la lumière ou à l'intimité n'est pas le même.",
          "C'est pourquoi la première question à se poser face à un architecte n'est pas « est-ce que j'aime ce qu'il fait ? », mais « est-ce qu'il cherche à comprendre comment je vis, avant de dessiner quoi que ce soit ? ». Cette nuance change tout dans la suite du projet.",
        ],
      },
      {
        heading: "Entre maîtrise technique et véritable écoute du client",
        paragraphs: [
          "Le métier d'architecte d'intérieur réunit deux compétences rarement présentes au même niveau chez une même personne : une compréhension technique et spatiale aiguë — structure, lumière, circulation, volumes, contraintes du bâti — et une capacité d'écoute suffisamment fine pour traduire les besoins, parfois mal formulés, d'un client en parti pris de conception.",
          "Un bon architecte ne se contente pas d'optimiser un plan. Il observe comment vous décrivez votre quotidien, il repère ce que vous ne dites pas explicitement mais que vos habitudes révèlent, et il transforme cette matière en décisions concrètes : où placer une cloison, comment organiser une circulation, quelle pièce mérite la meilleure lumière de la journée. Cette double compétence — technique et humaine — est précisément ce qui distingue un projet pensé d'un projet simplement décoré.",
        ],
        image: {
          src: "/assets/images/architecte-interieur-paris-conception-plans-bureau-etude.jpg",
          caption: "Étude de plans et conception d'un projet, Supra Studio",
        },
      },
      {
        heading: "Concevoir un espace qui fonctionne, avant de penser à l'esthétique",
        paragraphs: [
          "Un intérieur réussi ne se juge pas uniquement à sa photographie. Il se juge à l'usage, dans la durée : est-ce que la cuisine reste pratique un soir de semaine chargé ? Est-ce que la chambre reste reposante malgré le bruit de la rue ? Est-ce que l'espace de travail reste fonctionnel six mois après l'emménagement, une fois l'enthousiasme de la nouveauté retombé ?",
          "C'est là que se situe le véritable rôle de l'architecte d'intérieur : au-delà de l'esthétique, il conçoit un espace qui fonctionne. Le « joli » est une conséquence de ce travail, jamais son point de départ. Un intérieur peut être spectaculaire en photo et pourtant inconfortable à vivre ; à l'inverse, un intérieur conçu avec rigueur procure un confort silencieux, qui ne saute pas toujours aux yeux immédiatement, mais qui se ressent chaque jour.",
        ],
      },
      {
        heading: "Transformer les contraintes de votre logement en véritables atouts",
        paragraphs: [
          "Un appartement parisien ancien, mal agencé, aux volumes complexes ou aux surfaces limitées, est souvent perçu par son propriétaire comme une suite de problèmes à résoudre : une pièce trop petite, un couloir qui mange de l'espace, une configuration qui semble figée depuis des décennies.",
          "C'est précisément là qu'intervient la valeur d'un bon architecte : là où vous ne voyez qu'une contrainte, il voit une opportunité de conception. Un mur jugé gênant peut devenir l'occasion de repenser toute une circulation. Une pièce borgne peut se transformer en espace à vivre grâce à un jeu de lumière indirecte. Cette capacité à retourner une difficulté en parti pris architectural est l'un des signes les plus fiables d'un professionnel expérimenté — et l'un des éléments les plus difficiles à évaluer sur un simple book de réalisations.",
        ],
      },
      {
        heading: "Les signes qui révèlent une véritable qualité de raisonnement",
        paragraphs: [
          "Si l'on devait retenir un seul critère de sélection, ce serait celui-ci : jugez la manière dont un architecte raisonne, pas uniquement ce qu'il produit visuellement. Lors d'un premier échange, certains signes ne trompent pas : **il pose des questions sur votre quotidien avant de parler de style ou de matériaux** ; **il explique le pourquoi d'une proposition**, pas seulement comment elle sera réalisée ; **il est capable de remettre en question une idée que vous aviez en tête**, en expliquant son raisonnement, plutôt que de l'exécuter sans recul ; et **il distingue clairement, dans son discours, ce qui relève de ses goûts personnels et ce qui relève de votre usage réel de l'espace**.",
          "Un book de réalisations est utile pour évaluer une sensibilité générale, une qualité d'exécution, une cohérence de travail. Mais il ne doit jamais être le seul critère de choix : un intérieur que vous ne trouvez « pas à votre goût » en photo peut avoir été conçu suivant un raisonnement irréprochable pour un client dont les besoins n'étaient simplement pas les vôtres.",
        ],
      },
      {
        heading: "Révéler une identité plutôt que reproduire une mode",
        paragraphs: [
          "Les tendances passent. Un intérieur conçu uniquement pour coller à l'esthétique du moment vieillit mal, précisément parce qu'il n'a jamais été pensé pour ses habitants, mais pour une époque. À l'inverse, un intérieur conçu à partir d'une écoute réelle — de vos habitudes, de votre histoire, de votre manière d'occuper un lieu — traverse les années sans se démoder, parce qu'il n'a jamais cherché à suivre une mode : il a cherché à révéler une identité.",
          "C'est tout l'enjeu de bien choisir son architecte d'intérieur : ne pas chercher quelqu'un qui reproduira un style que vous avez repéré ailleurs, mais quelqu'un capable de s'approprier vos idées, de les structurer, et de les mettre en œuvre avec son savoir-faire. L'architecte n'est pas là pour imposer sa patte à tout prix ; il est là pour donner forme, avec expertise et exigence, à ce que vous êtes réellement.",
        ],
      },
      {
        heading: "L'approche de Supra Studio",
        paragraphs: [
          "Chez Supra Studio, chaque projet commence par une conversation, bien avant le premier croquis. Comprendre comment vous vivez, ce qui vous pèse dans votre logement actuel, ce à quoi vous ne voulez surtout pas renoncer : cette phase d'écoute conditionne toutes les décisions qui suivront. Notre rôle n'est pas de vous proposer un style qui nous est propre et que nous dupliquerions d'un projet à l'autre, mais de concevoir, à partir de votre identité et des contraintes réelles de votre bien, un intérieur qui vous ressemble durablement.",
          "**Vous envisagez un projet de rénovation ou d'aménagement à Paris ?** [Prenez rendez-vous](https://calendly.com/paul-cohen-suprastudio/30min) pour un premier échange, ou [contactez-nous](/contact) pour en discuter.",
        ],
      },
      {
        heading: "Questions fréquentes",
        paragraphs: [
          "**Comment savoir si un architecte d'intérieur me correspond, au-delà de son book de réalisations ?** Observez sa manière de poser des questions lors du premier échange : s'intéresse-t-il d'abord à votre style de vie, ou passe-t-il directement aux choix esthétiques ? Un bon architecte distingue clairement ses préférences personnelles de votre usage réel de l'espace.",
          "**Faut-il choisir un architecte dont le style correspond exactement à nos goûts ?** Non, pas nécessairement. Un architecte compétent est capable d'adapter son raisonnement et sa sensibilité à des clients très différents. Le critère déterminant est sa capacité d'écoute et sa rigueur de conception, bien plus que la ressemblance stylistique avec ses précédents projets.",
          "**Pourquoi un architecte peut-il voir des opportunités là où je ne vois que des contraintes ?** Parce que sa formation et son expérience lui permettent de raisonner en termes de volumes, de lumière et de circulation, au-delà de l'agencement existant. Une contrainte apparente — un mur, une pièce mal exposée — devient alors un point de départ de conception plutôt qu'un obstacle.",
          "**Quelle est la différence entre un intérieur « tendance » et un intérieur conçu pour durer ?** Un intérieur tendance répond à une esthétique du moment, qui se démode avec le temps. Un intérieur conçu à partir d'une véritable écoute du client reflète une identité propre, qui reste pertinente et agréable à vivre indépendamment des modes. Pour comprendre concrètement comment nous construisons cette écoute en amont d'un chiffrage, consultez notre article sur les [honoraires d'un architecte d'intérieur à Paris](/journal/honoraires-architecte-interieur-paris).",
        ],
      },
    ],
    keywords: [
      "Choisir architecte d'intérieur Paris",
      "Critères sélection architecte d'intérieur",
      "Comment choisir son architecte d'intérieur",
    ],
    relatedProjects: ["casa-duy", "maison-kleber"],
  },
];

export function getArticleBySlug(slug: string) {
  return JOURNAL_ARTICLES.find((a) => a.slug === slug);
}

// Articles triés du plus récent au plus ancien.
export function getSortedArticles() {
  return [...JOURNAL_ARTICLES].sort((a, b) => {
    if (!!a.pinned !== !!b.pinned) return a.pinned ? -1 : 1;
    return a.date < b.date ? 1 : -1;
  });
}
